package es.unizar.eina.notepad.ui;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModelProvider;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import es.unizar.eina.notepad.R;
import es.unizar.eina.notepad.database.Parcela;
import es.unizar.eina.notepad.database.Reserva;

/**
 * Pantalla de inicio para la ejecución de pruebas.
 * Permite realizar pruebas de caja negra, pruebas de volumen y pruebas de sobrecarga.
 * Incluye botones para iniciar cada tipo de prueba y muestra logs con los resultados.
 */
public class PruebasInicioActivity extends AppCompatActivity {
    Button mBotonEjCajaNegra;
    Button mBotonEjVolumen;
    Button mBotonEjSobrecarga;

    // ViewModels para interactuar con los datos de parcelas y reservas
    private ParcelaViewModel mParcelaViewModel;
    private ReservaViewModel mReservaViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pruebasinicio);

        // Inicialización de los botones
        mBotonEjCajaNegra = findViewById(R.id.button_ejecutar_caja_negra);
        mBotonEjVolumen = findViewById(R.id.button_ejecutar_volumen);
        mBotonEjSobrecarga = findViewById(R.id.button_ejecutar_sobrecarga);

        // Configuración de los eventos de los botones
        mBotonEjCajaNegra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ejecutarPruebasCajaNegra();
            }
        });

        mBotonEjVolumen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { ejecutarPruebasVolumen(); }
        });

        mBotonEjSobrecarga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { ejecutarPruebasSobrecarga(); }
        });

        mParcelaViewModel = new ViewModelProvider(this).get(ParcelaViewModel.class);
        mReservaViewModel = new ViewModelProvider(this).get(ReservaViewModel.class);
    }

    /**
     * Ejecuta las pruebas de caja negra para las operaciones de parcelas y reservas.
     */
    private void ejecutarPruebasCajaNegra() {
        ejecutarPruebasInsertParcelas();
        ejecutarPruebasInsertReservas();

        ejecutarPruebasUpdateParcelas();
        ejecutarPruebasUpdateReservas();

        ejecutarPruebasDeleteParcelas();
        ejecutarPruebasDeleteReservas();
    }

    /**
     * Ejecuta las pruebas de volumen para parcelas y reservas.
     * Verifica el manejo del máximo número de registros.
     */
    private void ejecutarPruebasVolumen() {
        ejecutarPruebaVolumenParcelas();
        ejecutarPruebaVolumenReservas();
    }






    /**
     * Ejecuta pruebas de sobrecarga.
     * Intenta insertar una parcela con un identificador extremadamente largo para probar los límites del sistema.
     */
    private void ejecutarPruebasSobrecarga() {
        Parcela parcela = new Parcela("PRUEBA SOBRECARGA", 12.0, true, true, 3, 20.0);
        long j = 1000;
        String cadena = "";
        for(int i=0; i<j; i++) {
            cadena = cadena + "a";
        }
        // Itera aumentando el tamaño del ID hasta que falle
        while(true) {
            j = j * 2;
            try {
                for (int i = 0; i < 2; i++) {
                    cadena = cadena + cadena;
                }
            } catch (OutOfMemoryError e) {
                Log.d("PruebasInicioActivity", "Fallo al concatenar con " + j + " caracteres");
                return;
            }
            Log.d("PruebasInicioActivity", "prueba con id con " + j + " caracteres");
            parcela.setId(cadena);
            int numParcelasAntes = mParcelaViewModel.getNumeroParcelas();
            mParcelaViewModel.insert(parcela);
            int numParcelasDespues = mParcelaViewModel.getNumeroParcelas();
            if (numParcelasDespues == numParcelasAntes) {
                Log.d("PruebasInicioActivity", "insert fallido con un id con " + j + " caracteres");
                return;
            }
            else {
                mParcelaViewModel.delete(parcela);
                Log.d("PruebasInicioActivity", "insert correcto con un id con " + j + " caracteres");
            }
        }
    }







    /**
     * Pruebas de inserción para las parcelas.
     * Valida casos válidos y no válidos de entrada.
     */
    private void ejecutarPruebasInsertParcelas() {
        // CLASE VÁLIDA
        // Caso de prueba 1
        Log.d("PruebasInicioActivity", "CP1 insert ParcelaRepository:");
        Parcela parcela1 = new Parcela("VALLE DE PRUEBA", 12.0, true, true, 3, 30.0);
        mParcelaViewModel.insert(parcela1);

        // CLASES NO VÁLIDAS
        // Caso de prueba 2
        Log.d("PruebasInicioActivity", "CP2 insert ParcelaRepository:");
        Parcela parcela2 = new Parcela(null, 12.0, true, true, 3, 30.0);
        mParcelaViewModel.insert(parcela2);

        // Caso de prueba 3
        Log.d("PruebasInicioActivity", "CP3 insert ParcelaRepository:");
        Parcela parcela3 = new Parcela("", 12.0, true, true, 3, 30.0);
        mParcelaViewModel.insert(parcela3);

        // Caso de prueba 4
        Log.d("PruebasInicioActivity", "CP4 insert ParcelaRepository:");
        Parcela parcela4 = new Parcela("VALLE DE PRUEBA", 0.0, true, true, 3, 30.0);
        mParcelaViewModel.insert(parcela4);

        // Caso de prueba 5 (no se puede ejecutar por definición del tipo boolean)
//        Log.d("PruebasInicioActivity", "CP5 insert ParcelaRepository:");
//        Parcela parcela5 = new Parcela("VALLE DE PRUEBA", 12.0, 3, true, 3, 30.0);
//        mParcelaViewModel.insert(parcela5);

        // Caso de prueba 6 (no se puede ejecutar por definición del tipo boolean)
//        Log.d("PruebasInicioActivity", "CP6 insert ParcelaRepository:");
//        Parcela parcela6 = new Parcela("VALLE DE PRUEBA", 12.0, true, 3, 3, 30.0);
//        mParcelaViewModel.insert(parcela6);

        // Caso de prueba 7
        Log.d("PruebasInicioActivity", "CP7 insert ParcelaRepository:");
        Parcela parcela7 = new Parcela("VALLE DE PRUEBA", 12.0, true, true, 0, 30.0);
        mParcelaViewModel.insert(parcela7);

        // Caso de prueba 8
        Log.d("PruebasInicioActivity", "CP8 insert ParcelaRepository:");
        Parcela parcela8 = new Parcela("VALLE DE PRUEBA", 12.0, true, true, 3, 0.0);
        mParcelaViewModel.insert(parcela8);
    }







    /**
     * Prueba de volumen para las parcelas.
     * Intenta insertar parcelas hasta alcanzar el número máximo permitido.
     */
    private void ejecutarPruebasUpdateParcelas() {
        Parcela parcela = new Parcela("VALLE DE PRUEBA", 12.0, true, true, 3, 30.0);

        // CLASE VÁLIDA
        // Caso de prueba 1
        Log.d("PruebasInicioActivity", "CP1 update ParcelaRepository:");
        mParcelaViewModel.update(parcela);

        // CLASES NO VÁLIDAS
        // Caso de prueba 2
        Log.d("PruebasInicioActivity", "CP2 update ParcelaRepository:");
        parcela.setTamano(0.0);
        mParcelaViewModel.update(parcela);
        parcela.setTamano(12.0);

        // Caso de prueba 3 (no se puede probar por definición del tipo boolean)

        // Caso de prueba 4 (no se puede probar por definición del tipo boolean)

        // Caso de prueba 5
        Log.d("PruebasInicioActivity", "CP5 update ParcelaRepository:");
        parcela.setNumMaxOcupantes(0);
        mParcelaViewModel.update(parcela);
        parcela.setNumMaxOcupantes(3);

        // Caso de prueba 6
        Log.d("PruebasInicioActivity", "CP6 update ParcelaRepository:");
        parcela.setPrecioPorPersona(0.0);
        mParcelaViewModel.update(parcela);
        parcela.setPrecioPorPersona(30.0);
    }







    /**
     * Pruebas de eliminación para parcelas.
     * Valida casos válidos y no válidos.
     */
    private void ejecutarPruebasDeleteParcelas() {
        Parcela parcela = new Parcela("VALLE DE PRUEBA", 12.0, true, true, 3, 30.0);

        // CLASE VÁLIDA
        // Caso de prueba 1
        Log.d("PruebasInicioActivity", "CP1 delete ParcelaRepository:");
        mParcelaViewModel.delete(parcela);

        // CLASES NO VÁLIDAS
        // Caso de prueba 2
        parcela.setId(null);
        Log.d("PruebasInicioActivity", "CP2 delete ParcelaRepository:");
        mParcelaViewModel.delete(parcela);

        // Caso de prueba 3
        parcela.setId("");
        Log.d("PruebasInicioActivity", "CP3 delete ParcelaRepository:");
        mParcelaViewModel.delete(parcela);
    }







    /**
     * Pruebas de inserción para reservas.
     * Valida casos válidos y no válidos de entrada.
     */
    private void ejecutarPruebasInsertReservas() {
        // CLASE VÁLIDA
        // Caso de prueba 1
        Log.d("PruebasInicioActivity", "CP1 insert ReservaRepository:");
        Reserva reserva1 = new Reserva("Pepe", 662215958, "12/06/2024", "15/06/2024", 2);
        mReservaViewModel.insert(reserva1);

        // CLASES NO VÁLIDAS
        // Caso de prueba 2 (no se puede probar porque el id se auto-asigna al insertar)

        // Caso de prueba 3
        Log.d("PruebasInicioActivity", "CP3 insert ReservaRepository:");
        Reserva reserva3 = new Reserva(null, 662215958, "12/06/2024", "15/06/2024", 2);
        mReservaViewModel.insert(reserva3);

        // Caso de prueba 4
        Log.d("PruebasInicioActivity", "CP4 insert ReservaRepository:");
        Reserva reserva4 = new Reserva("", 662215958, "12/06/2024", "15/06/2024", 2);
        mReservaViewModel.insert(reserva4);

        // Caso de prueba 5
        Log.d("PruebasInicioActivity", "CP5 insert ReservaRepository:");
        Reserva reserva5 = new Reserva("Pepe", 62, "12/06/2024", "15/06/2024", 2);
        mReservaViewModel.insert(reserva5);

        // Caso de prueba 6 (no se puede probar porque el entero es demasiado largo (overflow))
//        Log.d("PruebasInicioActivity", "CP6 insert ReservaRepository:");
//        Reserva reserva6 = new Reserva("Pepe", 6622159588888, "12/06/2024", "15/06/2024", 2);
//        mReservaViewModel.insert(reserva6);

        // Caso de prueba 7 (no se puede probar porque sólo podemos insertar enteros)
//        Log.d("PruebasInicioActivity", "CP7 insert ReservaRepository:");
//        Reserva reserva7 = new Reserva("Pepe", 662-15a58, "12/06/2024", "15/06/2024", 2);
//        mReservaViewModel.insert(reserva7);

        // Caso de prueba 8
        Log.d("PruebasInicioActivity", "CP8 insert ReservaRepository:");
        Reserva reserva8 = new Reserva("Pepe", 662215958, "12/6/2024", "15/06/2024", 2);
        mReservaViewModel.insert(reserva8);

        // Caso de prueba 9
        Log.d("PruebasInicioActivity", "CP9 insert ReservaRepository:");
        Reserva reserva9 = new Reserva("Pepe", 662215958, "0012/0006/2024", "15/06/2024", 2);
        mReservaViewModel.insert(reserva9);

        // Caso de prueba 10
        Log.d("PruebasInicioActivity", "CP10 insert ReservaRepository:");
        Reserva reserva10 = new Reserva("Pepe", 662215958, "12/ju/2024", "15/06/2024", 2);
        mReservaViewModel.insert(reserva10);

        // Caso de prueba 11
        Log.d("PruebasInicioActivity", "CP11 insert ReservaRepository:");
        Reserva reserva11 = new Reserva("Pepe", 662215958, "12-06-2024", "15/06/2024", 2);
        mReservaViewModel.insert(reserva11);

        // Caso de prueba 12
        Log.d("PruebasInicioActivity", "CP12 insert ReservaRepository:");
        Reserva reserva12 = new Reserva("Pepe", 662215958, "12/06/2024", "15/6/2024", 2);
        mReservaViewModel.insert(reserva12);

        // Caso de prueba 13
        Log.d("PruebasInicioActivity", "CP13 insert ReservaRepository:");
        Reserva reserva13 = new Reserva("Pepe", 662215958, "12/06/2024", "0015/0006/2024", 2);
        mReservaViewModel.insert(reserva13);

        // Caso de prueba 14
        Log.d("PruebasInicioActivity", "CP14 insert ReservaRepository:");
        Reserva reserva14 = new Reserva("Pepe", 662215958, "12/06/2024", "15/ju/2024", 2);
        mReservaViewModel.insert(reserva14);

        // Caso de prueba 15
        Log.d("PruebasInicioActivity", "CP15 insert ReservaRepository:");
        Reserva reserva15 = new Reserva("Pepe", 662215958, "12/06/2024", "15-06-2024", 2);
        mReservaViewModel.insert(reserva15);

        // Caso de prueba 16
        Log.d("PruebasInicioActivity", "CP16 insert ReservaRepository:");
        Reserva reserva16 = new Reserva("Pepe", 662215958, "12/06/2024", "15/06/2024", 0);
        mReservaViewModel.insert(reserva16);
    }






    /**
     * Pruebas de actualización para reservas.
     * Valida casos válidos y no válidos de entrada.
     */
    private void ejecutarPruebasUpdateReservas() {
        Reserva reserva = new Reserva("Pepe", 662215958, "12/06/2024", "15/06/2024", 2);

        // CLASE VÁLIDA
        // Caso de prueba 1
        Log.d("PruebasInicioActivity", "CP1 update ReservaRepository:");
        mReservaViewModel.update(reserva);

        // CLASES NO VÁLIDAS
        // Caso de prueba 2
        Log.d("PruebasInicioActivity", "CP2 update ReservaRepository:");
        reserva.setNomCliente(null);
        mReservaViewModel.update(reserva);

        // Caso de prueba 3
        Log.d("PruebasInicioActivity", "CP3 update ReservaRepository:");
        reserva.setNomCliente("");
        mReservaViewModel.update(reserva);
        reserva.setNomCliente("Pepe");

        // Caso de prueba 4
        Log.d("PruebasInicioActivity", "CP4 update ReservaRepository:");
        reserva.setNumMovil(62);
        mReservaViewModel.update(reserva);
        reserva.setNumMovil(662215958);

        // Caso de prueba 5 (no se puede probar por tamaño máximo del tipo int)
//        Log.d("PruebasInicioActivity", "CP5 update ReservaRepository:");
//        reserva.setNumMovil(6622159588888);
//        mReservaViewModel.update(reserva);
//        reserva.setNumMovil(662215958);

        // Caso de prueba 6 (no se puede probar por definición del tipo int)
//        Log.d("PruebasInicioActivity", "CP6 update ReservaRepository:");
//        reserva.setNumMovil(662-15a58);
//        mReservaViewModel.update(reserva);
//        reserva.setNumMovil(662215958);

        // Caso de prueba 7
        Log.d("PruebasInicioActivity", "CP7 update ReservaRepository:");
        reserva.setFEnt("12/6/2025");
        mReservaViewModel.update(reserva);

        // Caso de prueba 8
        Log.d("PruebasInicioActivity", "CP8 update ReservaRepository:");
        reserva.setFEnt("0012/0006/2025");
        mReservaViewModel.update(reserva);

        // Caso de prueba 9
        Log.d("PruebasInicioActivity", "CP9 update ReservaRepository:");
        reserva.setFEnt("12/ju/2025");
        mReservaViewModel.update(reserva);

        // Caso de prueba 10
        Log.d("PruebasInicioActivity", "CP10 update ReservaRepository:");
        reserva.setFEnt("12-6-2025");
        mReservaViewModel.update(reserva);
        reserva.setFEnt("12/06/2025");

        // Caso de prueba 11
        Log.d("PruebasInicioActivity", "CP11 update ReservaRepository:");
        reserva.setFSal("15/6/2025");
        mReservaViewModel.update(reserva);

        // Caso de prueba 12
        Log.d("PruebasInicioActivity", "CP12 update ReservaRepository:");
        reserva.setFSal("0015/0006/2025");
        mReservaViewModel.update(reserva);

        // Caso de prueba 13
        Log.d("PruebasInicioActivity", "CP13 update ReservaRepository:");
        reserva.setFSal("15/ju/2025");
        mReservaViewModel.update(reserva);

        // Caso de prueba 14
        Log.d("PruebasInicioActivity", "CP14 update ReservaRepository:");
        reserva.setFSal("15-6-2025");
        mReservaViewModel.update(reserva);
        reserva.setFSal("15/06/2025");

        // Caso de prueba 15
        Log.d("PruebasInicioActivity", "CP15 update ReservaRepository:");
        reserva.setNumParcelas(0);
        mReservaViewModel.update(reserva);
        reserva.setNumParcelas(2);
    }







    /**
     * Pruebas de eliminación para reservas.
     * Valida casos válidos y no válidos de entrada.
     */
    private void ejecutarPruebasDeleteReservas() {
        Reserva reserva = new Reserva("Pepe", 662215958, "12/06/2024", "15/06/2024", 2);

        // CLASE VÁLIDA
        // Caso de prueba 1
        Log.d("PruebasInicioActivity", "CP1 delete ReservaRepository:");
        mReservaViewModel.delete(reserva);

        // CLASES NO VÁLIDAS
        // Caso de prueba 2
        reserva.setId(-1);
        Log.d("PruebasInicioActivity", "CP2 delete ReservaRepository:");
        mReservaViewModel.delete(reserva);
    }








    /**
    * Método que realiza pruebas de volumen para la tabla de Parcelas.
    * Inserta parcelas hasta alcanzar el máximo permitido, valida que no se puedan insertar más
    * y luego elimina todas las parcelas creadas durante la prueba.
    */
    private void ejecutarPruebaVolumenParcelas() {
        int parcelas = mParcelaViewModel.getNumeroParcelas();
        Log.d("PruebasInicioActivity", "hay " + parcelas + " parcelas");

        parcelas = mParcelaViewModel.getNumeroMaxParcelas() - parcelas;  // vamos a insertar hasta el máximo
        Parcela parcela = new Parcela("PRUEBA VOLUMEN", 1.0, true, true, 6, 20.0);
        for(int i=0; i<parcelas; i++) {
            parcela.setId("PRUEBA VOLUMEN " + i);
            mParcelaViewModel.insert(parcela);
            Log.d("PruebasInicioActivity", "insertada la parcela PRUEBA VOLUMEN " + i);
        }

        // esta ya tiene que fallar
        parcela.setId("PRUEBA VOLUMEN FALLO");
        Log.d("PruebasInicioActivity", "va a fallar este insert (ya hay max parcelas)");
        mParcelaViewModel.insert(parcela);

        // borramos todas las parcelas creadas para la prueba
        Log.d("PruebasInicioActivity", "eliminando las parcelas creadas para la prueba...");
        for(int i=0; i<parcelas; i++) {
            parcela.setId("PRUEBA VOLUMEN " + i);
            mParcelaViewModel.delete(parcela);
        }
        Log.d("PruebasInicioActivity", "ya se han eliminado todas las parcelas");
    }








    /**
    * Método que realiza pruebas de volumen para la tabla de Reservas.
    * Inserta reservas hasta alcanzar el máximo permitido, valida que no se puedan insertar más
    * y luego elimina todas las reservas creadas durante la prueba.
    */
    private void ejecutarPruebaVolumenReservas() {
        int reservasAntes = mReservaViewModel.getNumeroReservas();
        Log.d("PruebasInicioActivity", "hay " + reservasAntes + " reservas");

        int reservas = mReservaViewModel.getNumeroMaxReservas() - reservasAntes;  // vamos a insertar hasta el máximo
        Reserva reserva = new Reserva("CLIENTE", 600000000, "30/12/2025", "31/12/2025", 1);

        ExecutorService executor = Executors.newSingleThreadExecutor();
        for(int i=0; i<reservas; i++) {
            reserva.setNomCliente("CLIENTE " + i);
            mReservaViewModel.insert(reserva);
            Log.d("PruebasInicioActivity", "insertada la reserva CLIENTE " + i);
        }

        // esta ya tiene que fallar
        reserva.setNomCliente("CLIENTE FALLO");
        Log.d("PruebasInicioActivity", "va a fallar este insert (ya hay max reservas)");
        mReservaViewModel.insert(reserva);

        // borramos todas las reservas creadas para la prueba
        Log.d("PruebasInicioActivity", "eliminando las reservas creadas para la prueba...");
        LiveData<List<Reserva>> todasReservasLiveData = mReservaViewModel.getAllReservas();
        todasReservasLiveData.observe(this, todasReservas -> {
            if (todasReservas != null && todasReservas.size() > reservasAntes) {
                List<Reserva> reservasParaEliminar = todasReservas.subList(reservasAntes, todasReservas.size());

                for (Reserva r : reservasParaEliminar) {
                    mReservaViewModel.delete(r);
                    Log.d("PruebasInicioActivity", "eliminada la reserva con id " + r.getId());
                }
            }
        });
        Log.d("PruebasInicioActivity", "ya se han eliminado todas las reservas");
    }

}

