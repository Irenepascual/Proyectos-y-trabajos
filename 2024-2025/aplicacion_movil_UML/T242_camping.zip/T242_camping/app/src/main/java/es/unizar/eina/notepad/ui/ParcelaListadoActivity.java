package es.unizar.eina.notepad.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import es.unizar.eina.notepad.R;
import es.unizar.eina.notepad.database.Parcela;

/**
 * Pantalla que muestra un listado de las parcelas.
 * Para cada parcela, se visualiza:
 *  - Nombre (ID)
 *  - Tamaño
 *  - Precio por persona
 *  - Número máximo de ocupantes
 * Permite ordenar el listado según:
 *  - Identificador (Nombre)
 *  - Precio
 *  - Número de ocupantes
 */
public class ParcelaListadoActivity extends AppCompatActivity {

    private ParcelaViewModel mParcelaViewModel;
    private RecyclerView mRecyclerView;
    private ParcelaListadoAdapter mAdapter;

    private Spinner mSpinnerOrdenar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parcelas_list);

        // Configuración del RecyclerView y su adaptador
        mRecyclerView = findViewById(R.id.recyclerview_parcelas);
        mAdapter = new ParcelaListadoAdapter();
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Configuración del Spinner para seleccionar el criterio de ordenación
        mSpinnerOrdenar = findViewById(R.id.spinner_ordenar);
        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(
                this, R.array.criterios_ordenacion, android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mSpinnerOrdenar.setAdapter(spinnerAdapter);

        mParcelaViewModel = new ViewModelProvider(this).get(ParcelaViewModel.class);

        // Configuración del listener del Spinner para manejar el cambio de criterio de ordenación
        mSpinnerOrdenar.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0: // Ordenar por Nombre (ID en este caso)
                        observarListaParcelas(mParcelaViewModel.getOrderedParcelasID());
                        break;
                    case 1: // Ordenar por Precio
                        observarListaParcelas(mParcelaViewModel.getOrderedParcelasPRECIO());
                        break;
                    case 2: // Ordenar por Ocupantes
                        observarListaParcelas(mParcelaViewModel.getOrderedParcelasOCUPANTES());
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // No hacer nada si no hay selección
            }
        });

        // Cargar la lista inicial de parcelas (sin ordenar)
        observarListaParcelas(mParcelaViewModel.getAllParcelas());
    }

    /**
     * Observa una lista de parcelas en LiveData y actualiza el adaptador del RecyclerView.
     * @param parcelasLiveData LiveData que contiene la lista de parcelas a observar.
     */
    private void observarListaParcelas(LiveData<List<Parcela>> parcelasLiveData) {
        parcelasLiveData.observe(this, parcelas -> {
            if (parcelas != null) {
                mAdapter.setParcelas(parcelas);
            }
        });
    }
}


