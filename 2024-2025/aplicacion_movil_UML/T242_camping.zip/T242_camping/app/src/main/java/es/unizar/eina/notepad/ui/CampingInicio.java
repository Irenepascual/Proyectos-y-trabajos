package es.unizar.eina.notepad.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import es.unizar.eina.notepad.R;

/**
 * Pantalla principal de la aplicación Camping.
 * Proporciona acceso a las diferentes funcionalidades mediante tres botones:
 * - Gestión de parcelas
 * - Gestión de reservas
 * - Pantalla de pruebas
 */
public class CampingInicio extends AppCompatActivity {
    Button mBotonParcelas;
    Button mBotonReservas;
    Button mBotonPruebas;

    /**
     * Método llamado cuando se crea la actividad.
     * Se utiliza para inicializar los componentes de la UI y configurar los eventos de los botones.
     * @param savedInstanceState Estado guardado de la actividad, si existe.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_campinginicio);

        mBotonParcelas = findViewById(R.id.button_parcelas);
        mBotonReservas = findViewById(R.id.button_reservas);
        mBotonPruebas = findViewById(R.id.button_pruebas);

        // Configurar el evento del botón para abrir la pantalla de gestión de parcelas
        mBotonParcelas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                verParcelaInicio();
            }
        });

        // Configurar el evento del botón para abrir la pantalla de gestión de reservas
        mBotonReservas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                verReservaInicio();
            }
        });

        // Configurar el evento del botón para abrir la pantalla de pruebas
        mBotonPruebas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { verPruebasInicio(); }
        });
    }

    /**
     * Inicia la actividad para la gestión de parcelas.
     * Llama a la actividad `ParcelaInicioActivity`.
     */
    private void verParcelaInicio() {
        Intent intent = new Intent(CampingInicio.this, ParcelaInicioActivity.class);
        startActivity(intent);
    }

    /**
     * Inicia la actividad para la gestión de reservas.
     * Llama a la actividad `ReservaInicioActivity`.
     */
    private void verReservaInicio() {
       Intent intent = new Intent(CampingInicio.this, ReservaInicioActivity.class);
       startActivity(intent);
    }

    /**
     * Inicia la actividad para la sección de pruebas.
     * Llama a la actividad `PruebasInicioActivity`.
     */
    private void verPruebasInicio() {
        Intent intent = new Intent(CampingInicio.this, PruebasInicioActivity.class);
        startActivity(intent);
    }
}