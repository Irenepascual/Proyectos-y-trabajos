package es.unizar.eina.notepad.ui;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;
import es.unizar.eina.notepad.database.Asociacion;
import es.unizar.eina.notepad.database.AsociacionRepository;

/**
 * ViewModel para gestionar los datos de las asociaciones.
 * Proporciona una interfaz para que la UI interactúe con el repositorio sin
 * conocer los detalles internos de la base de datos.
 * Extiende AndroidViewModel para tener acceso al contexto de la aplicación.
 */
public class AsociacionViewModel extends AndroidViewModel {

    private final AsociacionRepository mRepository;
    private final LiveData<List<Asociacion>> mAllAsociaciones;

    /**
     * Constructor del ViewModel de Asociación.
     * @param application Contexto de la aplicación, necesario para inicializar el repositorio.
     */
    public AsociacionViewModel(Application application) {
        super(application);
        mRepository = new AsociacionRepository(application);
        mAllAsociaciones = mRepository.getAllAsociaciones();
    }

    /**
     * Devuelve un objeto LiveData que contiene la lista de todas las asociaciones.
     * La UI puede observar este LiveData para recibir actualizaciones automáticas cuando los datos cambien.
     * @return Lista observable de todas las asociaciones.
     */
    public LiveData<List<Asociacion>> getAllAsociaciones() {
        return mAllAsociaciones;
    }

    /**
     * Solicita la eliminación de una asociación específica.
     * @param asociacion Asociación que se desea eliminar.
     */
    public void delete(Asociacion asociacion) {
        mRepository.delete(asociacion);
    }

    /**
     * Solicita la actualización de una asociación específica.
     * @param asociacion Asociación que se desea actualizar.
     */
    public void update(Asociacion asociacion) {
        mRepository.update(asociacion);
    }

    /**
     * Solicita la inserción de una nueva asociación.
     * @param asociacion Asociación que se desea insertar.
     * @return ID de la asociación insertada o -1 si la operación falla.
     */
    public long insert(Asociacion asociacion) {
        return mRepository.insert(asociacion);
    }

    /**
     * Elimina todas las asociaciones relacionadas con una reserva específica.
     * @param reservaId ID de la reserva cuyas asociaciones se desean eliminar.
     */
    public void deleteAllAsociacionesByReserva(int reservaId) {
        mRepository.deleteAllAsociacionesByReserva(reservaId);
    }
}
