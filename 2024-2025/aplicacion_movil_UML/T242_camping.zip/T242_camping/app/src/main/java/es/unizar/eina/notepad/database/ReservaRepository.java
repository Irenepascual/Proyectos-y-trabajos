package es.unizar.eina.notepad.database;


import android.app.Application;
import android.util.Log;

import androidx.lifecycle.LiveData;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Clase que gestiona el acceso a la fuente de datos.
 * Interacciona con la base de datos a través de las clases `CampingRoomDatabase` y `ReservaDao`.
 * Proporciona métodos para realizar operaciones CRUD y consultas adicionales relacionadas con reservas.
 */
public class ReservaRepository {

    private final ReservaDao mReservaDao;
    private final LiveData<List<Reserva>> mAllReservas;
    private final LiveData<List<Reserva>> mOrderedReservasNOM;
    private final LiveData<List<Reserva>> mOrderedReservasNUMMOVIL;
    private final LiveData<List<Reserva>> mOrderedReservasFENT;

    private final long TIMEOUT = 15000;

    /**
     * Constructor que inicializa el repositorio de reservas.
     * Obtiene la instancia de la base de datos y los DAOs necesarios.
     * @param application Contexto de la aplicación.
     */
    public ReservaRepository(Application application) {
        CampingRoomDatabase db = CampingRoomDatabase.getDatabase(application);
        mReservaDao = db.reservaDao();
        mAllReservas = mReservaDao.getAllReservas();
        mOrderedReservasNOM = mReservaDao.getOrderedReservasNOM();
        mOrderedReservasNUMMOVIL = mReservaDao.getOrderedReservasNUMMOVIL();
        mOrderedReservasFENT = mReservaDao.getOrderedReservasFENT();
    }

    /**
     * Devuelve un objeto `LiveData` con todas las reservas almacenadas.
     * @return `LiveData` que contiene una lista de todas las reservas.
     */
    public LiveData<List<Reserva>> getAllReservas() {
        return mAllReservas;
    }

    /**
     * Devuelve un objeto `LiveData` con todas las reservas ordenadas por el nombre del cliente.
     * @return `LiveData` que contiene una lista de reservas ordenadas alfabéticamente por `nomCliente`.
     */
    public LiveData<List<Reserva>> getOrderedReservasNOM() { return mOrderedReservasNOM; }

    /**
     * Devuelve un objeto `LiveData` con todas las reservas ordenadas por el número móvil.
     * @return `LiveData` que contiene una lista de reservas ordenadas por `numMovil`.
     */
    public LiveData<List<Reserva>> getOrderedReservasNUMMOVIL() { return mOrderedReservasNUMMOVIL; }

    /**
     * Devuelve un objeto `LiveData` con todas las reservas ordenadas por la fecha de entrada.
     * @return `LiveData` que contiene una lista de reservas ordenadas por `fEnt`.
     */
    public LiveData<List<Reserva>> getOrderedReservasFENT() { return mOrderedReservasFENT; }

    /**
     * Devuelve un objeto `LiveData` con la reserva cuyo identificador coincide con el proporcionado.
     * @param id Identificador único de la reserva.
     * @return `LiveData` que contiene la reserva correspondiente al ID.
     */
    public LiveData<Reserva> getReservaById(int id) {return mReservaDao.getReservaById(id); }

    /**
     * Devuelve el número total de reservas almacenadas en la base de datos.
     * @return Número total de reservas, o -1 en caso de error.
     */
    public int getNumeroReservas() {
        Future<Integer> future = CampingRoomDatabase.databaseWriteExecutor.submit(
                () -> mReservaDao.getNumeroReservas());
        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.e("ReservaRepository", ex.getClass().getSimpleName() + ": " + ex.getMessage());
            return -1;
        }
    }

    /**
     * Inserta una nueva reserva en la base de datos.
     * @param reserva Objeto `Reserva` que contiene los datos de la nueva reserva.
     * @return ID de la reserva insertada, o -1 en caso de error.
     */
    public long insert(Reserva reserva) {
        Future<Long> future = CampingRoomDatabase.databaseWriteExecutor.submit(
                () -> mReservaDao.insert(reserva));
        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("ReservaRepository", ex.getClass().getSimpleName() + ex.getMessage());
            return -1;
        }
    }

    /**
     * Actualiza una reserva existente en la base de datos.
     * @param reserva Objeto `Reserva` con los datos actualizados.
     * @return Número de filas afectadas (1 si se actualizó correctamente, 0 si no se encontró la reserva).
     */
    public int update(Reserva reserva) {
        Future<Integer> future = CampingRoomDatabase.databaseWriteExecutor.submit(
                () -> mReservaDao.update(reserva));
        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("ReservaRepository", ex.getClass().getSimpleName() + ex.getMessage());
            return -1;
        }
    }

    /**
     * Elimina una reserva específica de la base de datos.
     * @param reserva Objeto `Reserva` que contiene el ID de la reserva a eliminar.
     * @return Número de filas afectadas (1 si se eliminó correctamente, 0 si no se encontró la reserva).
     */
    public int delete(Reserva reserva) {
        Future<Integer> future = CampingRoomDatabase.databaseWriteExecutor.submit(
                () -> mReservaDao.delete(reserva));
        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("ReservaRepository", ex.getClass().getSimpleName() + ex.getMessage());
            return -1;
        }
    }
}
