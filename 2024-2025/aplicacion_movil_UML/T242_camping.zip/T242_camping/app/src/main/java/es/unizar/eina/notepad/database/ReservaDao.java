package es.unizar.eina.notepad.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

/**
 * Definición de un Data Access Object (DAO) para gestionar las reservas.
 * Este DAO proporciona métodos para realizar operaciones (Crear, Leer, Actualizar, Eliminar)
 * y consultas adicionales sobre la tabla de reservas.
 */
@Dao
public interface ReservaDao {

    /**
     * Inserta una reserva en la base de datos.
     * Si ya existe una reserva con el mismo ID, se ignora la inserción.
     * @param reserva Objeto `Reserva` que se desea insertar.
     * @return El ID de la nueva reserva insertada, o -1 si la inserción fue ignorada.
     */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    long insert(Reserva reserva);

    /**
     * Actualiza los datos de una reserva existente en la base de datos.
     * @param reserva Objeto `Reserva` con los datos actualizados.
     * @return El número de filas afectadas (1 si se actualizó correctamente, 0 si no se encontró la reserva).
     */
    @Update
    int update(Reserva reserva);

     /**
     * Elimina una reserva de la base de datos.
     * @param reserva Objeto `Reserva` que se desea eliminar.
     * @return El número de filas eliminadas (1 si se eliminó correctamente, 0 si no se encontró la reserva).
     */
    @Delete
    int delete(Reserva reserva);

    /**
     * Elimina todas las reservas de la base de datos.
     */
    @Query("DELETE FROM reserva")
    void deleteAll();

    /**
     * Devuelve una lista con todas las reservas almacenadas en la base de datos.
     * @return Objeto `LiveData` que contiene una lista de todas las reservas.
     */
    @Query("SELECT * FROM reserva")
    LiveData<List<Reserva>> getAllReservas();


    /**
     * Devuelve una lista con todas las reservas ordenadas alfabéticamente por el nombre del cliente.
     * @return Objeto `LiveData` que contiene una lista de reservas ordenadas por `nomCliente`.
     */
    @Query("SELECT * FROM reserva ORDER BY nomCliente ASC")
    LiveData<List<Reserva>> getOrderedReservasNOM();

    /**
     * Devuelve una lista con todas las reservas ordenadas por el número móvil en orden ascendente.
     * @return Objeto `LiveData` que contiene una lista de reservas ordenadas por `numMovil`.
     */
    @Query("SELECT * FROM reserva ORDER BY numMovil ASC")
    LiveData<List<Reserva>> getOrderedReservasNUMMOVIL();

    /**
     * Devuelve una lista con todas las reservas ordenadas por la fecha de entrada en orden ascendente.
     * Se utiliza una transformación de la fecha en formato DD/MM/AAAA para realizar la ordenación correctamente.
     * @return Objeto `LiveData` que contiene una lista de reservas ordenadas por `fEnt`.
     */
    @Query("SELECT * FROM reserva ORDER BY SUBSTR(fEnt, 7, 4) || SUBSTR(fEnt, 4, 2) || SUBSTR(fEnt, 1, 2) ASC")
    LiveData<List<Reserva>> getOrderedReservasFENT();

    /**
     * Devuelve una reserva específica cuyo ID coincide con el pasado como parámetro.
     * @param id Identificador único de la reserva.
     * @return Objeto `LiveData` que contiene la reserva con el ID proporcionado.
     */
    @Query("SELECT * FROM reserva WHERE id = :id")
    LiveData<Reserva> getReservaById(int id);

    /**
     * Devuelve el número total de reservas almacenadas en la base de datos.
     * @return Número total de reservas.
     */
    @Query("SELECT COUNT(*) FROM reserva")
    int getNumeroReservas();
}

