package es.unizar.eina.notepad.database;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;


/**
 * Clase Asociacion que representa una tabla en la base de datos "asociacion".
 * Esta entidad almacena las relaciones entre reservas y parcelas,
 * incluyendo el número de ocupantes por parcela.
 */@Entity(tableName = "asociacion")
public class Asociacion {
    // Clave primaria autogenerada para identificar cada asociación.
    @PrimaryKey(autoGenerate = true)
    @NonNull
    @ColumnInfo(name = "id")
    private int id;

    // Identificador de la reserva asociada.
    @NonNull
    @ColumnInfo(name = "reservaId")
    private int reservaId;

    // Identificador de la parcela asociada.
    @NonNull
    @ColumnInfo(name = "parcelaId")
    private String parcelaId;

    // Número de ocupantes por parcela para esta asociación.
    @NonNull
    @ColumnInfo(name = "numOcupantesPorParcela")
    private int numOcupantesPorParcela;

    /**
     * Constructor para crear una nueva instancia de Asociacion.
     *
     * @param reservaId             Identificador de la reserva.
     * @param parcelaId             Identificador de la parcela.
     * @param numOcupantesPorParcela Número de ocupantes para la parcela.
     */
    public Asociacion(@NonNull int reservaId, @NonNull String parcelaId, @NonNull int numOcupantesPorParcela) {
        this.reservaId = reservaId;
        this.parcelaId = parcelaId;
        this.numOcupantesPorParcela = numOcupantesPorParcela;
    }

    /**
     * Obtiene el identificador único de la asociación.
     *
     * @return id de la asociación.
     */
    public int getId() {
        return id;
    }

    /**
     * Establece el identificador único de la asociación.
     *
     * @param id Nuevo identificador.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obtiene el identificador de la reserva asociada.
     *
     * @return Identificador de la reserva.
     */
    public int getReservaId() {
        return reservaId;
    }

    /**
     * Establece el identificador de la reserva asociada.
     *
     * @param reservaId Nuevo identificador de la reserva.
     */
    public void setReservaId(int reservaId) {
        this.reservaId = reservaId;
    }

    /**
     * Obtiene el identificador de la parcela asociada.
     *
     * @return Identificador de la parcela.
     */
    public String getParcelaId() {
        return parcelaId;
    }

    /**
     * Establece el identificador de la parcela asociada.
     *
     * @param parcelaId Nuevo identificador de la parcela.
     */
    public void setParcelaId(String parcelaId) {
        this.parcelaId = parcelaId;
    }

    /**
     * Obtiene el número de ocupantes por parcela.
     *
     * @return Número de ocupantes por parcela.
     */
    public int getNumOcupantesPorParcela() {
        return numOcupantesPorParcela;
    }

    /**
     * Establece el número de ocupantes por parcela.
     *
     * @param numOcupantesPorParcela Nuevo número de ocupantes por parcela.
     */
    public void setNumOcupantesPorParcela(int numOcupantesPorParcela) {
        this.numOcupantesPorParcela = numOcupantesPorParcela;
    }
}
