 package es.unizar.eina.notepad.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import es.unizar.eina.notepad.R;
import es.unizar.eina.notepad.database.Reserva;

/**
 * Adaptador para un RecyclerView que muestra una lista de reservas.
 * Proporciona opciones para editar, eliminar y enviar información sobre cada reserva.
 */
public class ReservaListAdapter extends RecyclerView.Adapter<ReservaListAdapter.ReservaViewHolder> {

   private List<Reserva> mReservas;
   private final OnEditClickListener mEditListener;
   private final OnDeleteClickListener mDeleteListener;
   private final OnSendClickListener mSendListener;

   // Interfaz para manejar clics en el botón de edición.
   public interface OnEditClickListener {
       void onEditClick(Reserva reserva);
   }

   // Interfaz para manejar clics en el botón de eliminación.
   public interface OnDeleteClickListener {
       void onDeleteClick(Reserva reserva);
   }

   // Interfaz para manejar clics en el botón de envío.
   public interface OnSendClickListener {
       void onSendClick(Reserva reserva);
   }

   /**
    * Constructor del adaptador.
    * @param editListener Listener para manejar eventos de edición.
    * @param deleteListener Listener para manejar eventos de eliminación.
    * @param sendListener Listener para manejar eventos de envío.
    */
   public ReservaListAdapter(OnEditClickListener editListener, OnDeleteClickListener deleteListener, OnSendClickListener sendListener) {
       mEditListener = editListener;
       mDeleteListener = deleteListener;
       mSendListener = sendListener;
   }

   /**
    * Actualiza la lista de reservas en el adaptador y notifica cambios en los datos.
    * @param reservas Nueva lista de reservas.
    */
   public void setReservas(List<Reserva> reservas) {
       mReservas = reservas;
       notifyDataSetChanged();
   }

   @NonNull
   @Override
   public ReservaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View itemView = LayoutInflater.from(parent.getContext())
               .inflate(R.layout.item_reserva, parent, false);
       return new ReservaViewHolder(itemView);
   }

   @Override
   public void onBindViewHolder(@NonNull ReservaViewHolder holder, int position) {
       if (mReservas != null) {
           Reserva current = mReservas.get(position);
           holder.bind(current, mEditListener, mDeleteListener, mSendListener);
       }
   }

   @Override
   public int getItemCount() {
       return (mReservas != null) ? mReservas.size() : 0;
   }

   /**
    * ViewHolder que representa un elemento individual en la lista de reservas.
    */
   static class ReservaViewHolder extends RecyclerView.ViewHolder {
       private final TextView reservaItemView;
       private final ImageButton buttonEdit;
       private final ImageButton buttonDelete;
       private final ImageButton buttonSend;

       /**
        * Constructor del ViewHolder. Inicializa las vistas del diseño.
        * @param itemView Vista del elemento inflada desde el diseño XML.
        */
       public ReservaViewHolder(@NonNull View itemView) {
           super(itemView);
           reservaItemView = itemView.findViewById(R.id.textViewReserva);
           buttonEdit = itemView.findViewById(R.id.buttonEdit);
           buttonDelete = itemView.findViewById(R.id.buttonDelete);
           buttonSend = itemView.findViewById(R.id.buttonSend);
       }

       /**
        * Enlaza una reserva específica con las vistas y listeners del ViewHolder.
        * @param reserva Objeto Reserva a mostrar.
        * @param editListener Listener para eventos de edición.
        * @param deleteListener Listener para eventos de eliminación.
        * @param sendListener Listener para eventos de envío.
        */
       public void bind(final Reserva reserva, final OnEditClickListener editListener, OnDeleteClickListener deleteListener, OnSendClickListener sendListener) {
           String texto = "Reserva de " + reserva.getNomCliente();
           reservaItemView.setText(texto);

           buttonEdit.setOnClickListener(v -> editListener.onEditClick(reserva));
           buttonDelete.setOnClickListener(v -> deleteListener.onDeleteClick(reserva));
           buttonSend.setOnClickListener(v -> sendListener.onSendClick(reserva));
       }
   }
}