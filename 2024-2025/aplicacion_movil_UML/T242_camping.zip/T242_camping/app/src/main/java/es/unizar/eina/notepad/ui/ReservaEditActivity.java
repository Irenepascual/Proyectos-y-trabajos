package es.unizar.eina.notepad.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.Observer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import android.text.TextWatcher;
import android.text.Editable;
import java.util.Calendar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.widget.AdapterView;
import java.util.HashSet;
import java.util.Set;

import es.unizar.eina.notepad.R;
import es.unizar.eina.notepad.database.Asociacion;
import es.unizar.eina.notepad.database.Reserva;
import es.unizar.eina.notepad.database.Parcela;

/**
 * Actividad para editar una reserva existente.
 * Permite modificar datos básicos de la reserva y gestionar asociaciones con parcelas.
 */
public class ReservaEditActivity extends AppCompatActivity {
    private TextView mTextId;
    private EditText mEditNomCliente, mEditNumMovil, mEditFEnt, mEditFSal, mEditNumParcelas;
    private LinearLayout contenedorParcelas;
    private Button buttonAddParcela, buttonSave;
    private TextView totalPrecio;

    // ViewModels para manejar la lógica de datos.
    private ReservaViewModel mReservaViewModel;
    private ParcelaViewModel mParcelaViewModel;
    private AsociacionViewModel mAsociacionViewModel;

    // Adaptador para manejar las asociaciones en un RecyclerView.
    private AsociacionListAdapter mAsociacionAdapter;

    private RecyclerView mRecyclerViewAsociaciones;
    private List<Parcela> listaParcelas = new ArrayList<>();
    private List<Asociacion> listaAsociaciones = new ArrayList<>();
    private List<Parcela> parcelasDisponibles = new ArrayList<>();
    private int reservaId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reserva_edit);

        // Inicialización de los ViewModels.
        mAsociacionViewModel = new ViewModelProvider(this).get(AsociacionViewModel.class);
        mParcelaViewModel = new ViewModelProvider(this).get(ParcelaViewModel.class);
        mReservaViewModel = new ViewModelProvider(this).get(ReservaViewModel.class);

        // Inicializar vistas
        contenedorParcelas = findViewById(R.id.contenedorParcelas);
        buttonAddParcela = findViewById(R.id.button_add_parcela);
        buttonSave = findViewById(R.id.button_save);

        // Inicializar ViewModels
        mParcelaViewModel = new ViewModelProvider(this).get(ParcelaViewModel.class);
        mAsociacionViewModel = new ViewModelProvider(this).get(AsociacionViewModel.class);

        mRecyclerViewAsociaciones = findViewById(R.id.recyclerViewAsociaciones);
        mRecyclerViewAsociaciones.setLayoutManager(new LinearLayoutManager(this));

        // Inicializamos los campos de texto
        mTextId = findViewById(R.id.text_id);
        mEditNomCliente = findViewById(R.id.edit_nomCliente);
        mEditNumMovil = findViewById(R.id.edit_numMovil);
        mEditFEnt = findViewById(R.id.edit_fEnt);
        mEditFSal = findViewById(R.id.edit_fSal);
        mEditNumParcelas = findViewById(R.id.edit_numParcelas);
        buttonSave = findViewById(R.id.button_save);
        contenedorParcelas = findViewById(R.id.contenedorParcelas);
        totalPrecio = findViewById(R.id.total_precio);

        // Recuperamos los datos del Intent
        if (getIntent() != null) {
            reservaId = getIntent().getIntExtra("reserva_id", 0);
            String reservaNombreCliente = getIntent().getStringExtra("reserva_nomCli");
            int reservaNumMovil = getIntent().getIntExtra("reserva_numMovil", 0);
            String reservaFEnt = getIntent().getStringExtra("reserva_fEnt");
            String reservaFSal = getIntent().getStringExtra("reserva_fSal");
            Integer reservaNumParcelas = getIntent().getIntExtra("reserva_numParcelas", 1);


            // Asignamos los valores a los campos de edición
            mTextId.setText(String.valueOf(reservaId));  // Solo mostramos el ID, no editable
            mEditNomCliente.setText(reservaNombreCliente);
            mEditNumMovil.setText(String.valueOf(reservaNumMovil));
            mEditFEnt.setText(reservaFEnt);
            mEditFSal.setText(reservaFSal);
            mEditNumParcelas.setText(String.valueOf(reservaNumParcelas));
        }

        // Observa las asociaciones para esta reserva y actualiza la interfaz.
        mAsociacionViewModel.getAllAsociaciones().observe(this, asociaciones -> {
            listaAsociaciones.clear(); 
            for (Asociacion asociacion : asociaciones) {
                if (asociacion.getReservaId() == reservaId) {
                    listaAsociaciones.add(asociacion); 
                }
            }
            actualizarUIParcelas(); // Actualizar la interfaz con las asociaciones cargadas
            actualizarPrecioTotal(); 
        });

        // Observa todas las parcelas disponibles y configura el adaptador.
        mParcelaViewModel.getAllParcelas().observe(this, parcelas -> {
            if (parcelas != null) {
                listaParcelas = parcelas;

                AsociacionListAdapter.OnEditClickListener editClickListener = this::editAsociacion;
                AsociacionListAdapter.OnDeleteClickListener deleteClickListener = this::deleteAsociacion;

                mAsociacionAdapter = new AsociacionListAdapter(editClickListener, deleteClickListener, listaParcelas);
                mRecyclerViewAsociaciones.setAdapter(mAsociacionAdapter);
                
                actualizarParcelasDisponibles();
            }
        });

        mEditFEnt.addTextChangedListener(new TextWatcher() {
            private String formatoAnterior = "";

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                formatoAnterior = s.toString();
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // No es necesario manejar esta parte
            }

            @Override
            public void afterTextChanged(Editable s) {
                String textoActual = s.toString();

                if (!textoActual.equals(formatoAnterior)) {
                    String textoFormateado = formatearFecha(textoActual);
                    formatoAnterior = textoFormateado;
                    mEditFEnt.removeTextChangedListener(this);
                    mEditFEnt.setText(textoFormateado);
                    mEditFEnt.setSelection(textoFormateado.length());
                    mEditFEnt.addTextChangedListener(this);

                    actualizarParcelasDisponibles();
                }
            }
        });

        mEditFSal.addTextChangedListener(new TextWatcher() {
            private String formatoAnterior = "";

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                formatoAnterior = s.toString();
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // No es necesario manejar esta parte
            }

            @Override
            public void afterTextChanged(Editable s) {
                String textoActual = s.toString();

                if (!textoActual.equals(formatoAnterior)) {
                    String textoFormateado = formatearFecha(textoActual);
                    formatoAnterior = textoFormateado;
                    mEditFSal.removeTextChangedListener(this);
                    mEditFSal.setText(textoFormateado);
                    mEditFSal.setSelection(textoFormateado.length());
                    mEditFSal.addTextChangedListener(this);

                    actualizarParcelasDisponibles();
                }
            }
        });

        buttonAddParcela.setOnClickListener(v -> añadirNuevaParcela());
        buttonSave.setOnClickListener(v -> guardarCambios());
    }

    /**
     * Actualiza la lista de parcelas disponibles según las fechas de entrada y salida.
     */
    private void actualizarParcelasDisponibles() {
        String fechaEntrada = mEditFEnt.getText().toString().trim();
        String fechaSalida = mEditFSal.getText().toString().trim();

        // Si las fechas están configuradas, filtrar las parcelas disponibles
        if (fechaEntrada.length() == 10 && fechaSalida.length() == 10) {
            parcelasDisponibles = new ArrayList<>(listaParcelas);

            mAsociacionViewModel.getAllAsociaciones().observe(this, todasLasAsociaciones -> {
                List<Parcela> parcelasFiltradas = new ArrayList<>(parcelasDisponibles);

                for (Parcela parcela : parcelasDisponibles) {
                    for (Asociacion asociacion : todasLasAsociaciones) {
                        if (parcela.getId().equals(asociacion.getParcelaId())) {

                            mReservaViewModel.getReservaById(asociacion.getReservaId()).observe(this, reserva -> {
                                if (reserva != null) {
                                    if (reserva.getId() != reservaId) {
                                        if (fechasSeSolapan(fechaEntrada, fechaSalida, reserva.getFEnt(), reserva.getFSal())) {
                                            parcelasFiltradas.remove(parcela);
                                        }
                                    }
                                } 
                            });
                        }
                    }
                }
                parcelasDisponibles = parcelasFiltradas;
                if (parcelasDisponibles.isEmpty()) {
                    Toast.makeText(this, "No hay parcelas disponibles para las fechas seleccionadas.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        actualizarUIParcelas();
        actualizarPrecioTotal();
    }


    /**
     * Verifica si dos rangos de fechas se solapan.
     */
    private boolean fechasSeSolapan(String fEnt1, String fSal1, String fEnt2, String fSal2) {
        int inicio1 = convertirFechaAInt(fEnt1);
        int fin1 = convertirFechaAInt(fSal1);
        int inicio2 = convertirFechaAInt(fEnt2);
        int fin2 = convertirFechaAInt(fSal2);

        return !(fin1 <= inicio2 || fin2 <= inicio1);
    }

    /**
     * Convierte una fecha en formato DD/MM/AAAA a un entero para comparación.
     */
    private int convertirFechaAInt(String fecha) {
        String[] partes = fecha.split("/");
        return Integer.parseInt(partes[2] + partes[1] + partes[0]);
    }
    
    private void editAsociacion(Asociacion asociacion) {
        Toast.makeText(this, "Editando asociación: " + asociacion.getParcelaId(), Toast.LENGTH_SHORT).show();
    }

    private void deleteAsociacion(Asociacion asociacion) {
        Toast.makeText(ReservaEditActivity.this, "Eliminando asociación: " + asociacion.getParcelaId(), Toast.LENGTH_SHORT).show();
    }


    private void actualizarUIParcelas() {
        contenedorParcelas.removeAllViews();
        for (Asociacion asociacion : listaAsociaciones) {
            agregarParcelaUI(asociacion);
        }
    }

    /**
     * Añade una nueva parcela a la lista de asociaciones.
     */
    // private void añadirNuevaParcela() {
    //     actualizarParcelasDisponibles();
    //     if (!parcelasDisponibles.isEmpty()) {
    //         Asociacion nuevaAsociacion = new Asociacion(reservaId, parcelasDisponibles.get(0).getId(), 2);
    //         listaAsociaciones.add(nuevaAsociacion);
    //         mAsociacionViewModel.insert(nuevaAsociacion);
    //         agregarParcelaUI(nuevaAsociacion);
    //         mEditNumParcelas.setText(String.valueOf(listaAsociaciones.size()));
    //         actualizarPrecioTotal();
    //         Toast.makeText(this, "Parcela añadida", Toast.LENGTH_SHORT).show();
    //     } else {
    //         Toast.makeText(this, "No hay parcelas disponibles", Toast.LENGTH_SHORT).show();
    //     }
    // }


    private void añadirNuevaParcela() {
        actualizarParcelasDisponibles(); // Asegúrate de que la lista de parcelas disponibles está actualizada.
        if (!parcelasDisponibles.isEmpty()) {
            // Encuentra la primera parcela disponible que no esté ya seleccionada.
            Parcela parcelaAAnadir = null;
            for (Parcela parcela : parcelasDisponibles) {
                boolean yaSeleccionada = false;
                for (Asociacion asociacion : listaAsociaciones) {
                    if (asociacion.getParcelaId().equals(parcela.getId())) {
                        yaSeleccionada = true;
                        break;
                    }
                }
                if (!yaSeleccionada) {
                    parcelaAAnadir = parcela;
                    break;
                }
            }

            if (parcelaAAnadir != null) {
                Asociacion nuevaAsociacion = new Asociacion(reservaId, parcelaAAnadir.getId(), 1); // Suponiendo 1 como el número de ocupantes inicial
                listaAsociaciones.add(nuevaAsociacion);
                mAsociacionViewModel.insert(nuevaAsociacion);
                agregarParcelaUI(nuevaAsociacion);
                mEditNumParcelas.setText(String.valueOf(listaAsociaciones.size()));
                actualizarPrecioTotal();
                Toast.makeText(this, "Parcela añadida", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "No hay más parcelas disponibles", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "No hay parcelas disponibles", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isUpdating = false;


    /**
     *  Añade una nueva vista dinámica para una asociación con una parcela,
     *  permitiendo configurar la parcela y el número de ocupantes asociados.
     */
    private void agregarParcelaUI(Asociacion asociacion) {
        for (int i = 0; i < contenedorParcelas.getChildCount(); i++) {
            View view = contenedorParcelas.getChildAt(i);
            Spinner spinnerParcela = view.findViewById(R.id.spinner_parcela);
            Parcela parcelaSeleccionada = (Parcela) spinnerParcela.getSelectedItem();
            if (parcelaSeleccionada != null && parcelaSeleccionada.getId().equals(asociacion.getParcelaId())) {
                // Si ya existe, no agregamos otra vista
                return;
            }
        }
        
        View itemView = LayoutInflater.from(this).inflate(R.layout.item_asociacion_2, contenedorParcelas, false);
        Spinner spinnerParcela = itemView.findViewById(R.id.spinner_parcela);
        EditText editNumPersonas = itemView.findViewById(R.id.edit_num_personas);
        TextView precioParcela = itemView.findViewById(R.id.precio_parcela);
        androidx.appcompat.widget.AppCompatImageButton buttonDelete = itemView.findViewById(R.id.buttonDelete);

        // Configurar Spinner
        ArrayAdapter<Parcela> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, parcelasDisponibles);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerParcela.setAdapter(adapter);

        // Seleccionar la parcela actual
        int seleccionActual = -1;
        for (int i = 0; i < parcelasDisponibles.size(); i++) {
            if (parcelasDisponibles.get(i).getId().equals(asociacion.getParcelaId())) {
                seleccionActual = i;
                break;
            }
        }
        
        if (seleccionActual != -1) {
            spinnerParcela.setSelection(seleccionActual, false);
        } else if (!parcelasDisponibles.isEmpty()) {
            spinnerParcela.setSelection(0);
            Toast.makeText(this, "La parcela seleccionada no está disponible. Se ha asignado la primera disponible.", Toast.LENGTH_SHORT).show();
        }

        editNumPersonas.setText(String.valueOf(asociacion.getNumOcupantesPorParcela()));
        editNumPersonas.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (!isUpdating){
                    isUpdating = true;
                    String input = s.toString().trim();
                    if (!input.isEmpty()) {
                        int numPersonas = Integer.parseInt(input);
                        asociacion.setNumOcupantesPorParcela(numPersonas);

                        mAsociacionViewModel.update(asociacion);

                        actualizarPrecioParcela(precioParcela, spinnerParcela, numPersonas);
                        actualizarPrecioTotal();
                    }
                    isUpdating = false;
                }
            }
        });

        // Listener para el Spinner
        spinnerParcela.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!isUpdating){
                    isUpdating = true;
                    Parcela selectedParcela = adapter.getItem(position);
                    if (selectedParcela != null  && !selectedParcela.getId().equals(asociacion.getParcelaId())) {
                        asociacion.setParcelaId(selectedParcela.getId());
                        mAsociacionViewModel.update(asociacion);
                        int numPersonas = Integer.parseInt(editNumPersonas.getText().toString());
                        actualizarPrecioParcela(precioParcela, spinnerParcela, numPersonas);
                        actualizarPrecioTotal();
                    }
                    isUpdating = false;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        buttonDelete.setOnClickListener(v -> {
            mAsociacionViewModel.delete(asociacion);
            listaAsociaciones.remove(asociacion);
            contenedorParcelas.removeView(itemView);
            mEditNumParcelas.setText(String.valueOf(listaAsociaciones.size()));
            actualizarPrecioTotal();
            Toast.makeText(ReservaEditActivity.this, "Asociación eliminada", Toast.LENGTH_SHORT).show();
        });

        actualizarPrecioParcela(precioParcela, spinnerParcela, asociacion.getNumOcupantesPorParcela());
        contenedorParcelas.addView(itemView);
    }

    /**
     *  Calcula y muestra el precio total para una parcela seleccionada según el número de ocupantes.
     */
    private void actualizarPrecioParcela(TextView precioParcela, Spinner spinnerParcela, int numPersonas) {
        Parcela parcelaSeleccionada = (Parcela) spinnerParcela.getSelectedItem();
        if (parcelaSeleccionada != null) {
            double precioTotalParcela = parcelaSeleccionada.getPrecioPorPersona() * numPersonas;
            precioParcela.setText(String.format(Locale.getDefault(), "%.2f€", precioTotalParcela));
        }
    }

    /**
     *  Calcula y muestra el precio total de todas las parcelas asociadas en la reserva.
     */
    private void actualizarPrecioTotal() {
        double precioTotal = 0.0;

        for (Asociacion asociacion : listaAsociaciones) {
            for (Parcela parcela : listaParcelas) {
                if (parcela.getId().equals(asociacion.getParcelaId())) {
                    precioTotal += parcela.getPrecioPorPersona() * asociacion.getNumOcupantesPorParcela();
                    break;
                }
            }
        }

        totalPrecio.setText(String.format(Locale.getDefault(), "Total: %.2f€", precioTotal));
    }

    /**
     *  Formatea una cadena de texto en el formato "DD/MM/AAAA".
     */
    private String formatearFecha(String texto) {
        texto = texto.replaceAll("[^\\d]", ""); // Elimina todo lo que no sea un dígito

        StringBuilder resultado = new StringBuilder();
        int longitud = texto.length();

        for (int i = 0; i < longitud; i++) {
            if (i == 2 || i == 4) { // Añade "/" después del día y el mes
                resultado.append("/");
            }
            resultado.append(texto.charAt(i));
        }

        return resultado.toString();
    }

    /**
     *  Verifica si una fecha es válida y cumple el formato "DD/MM/AAAA".
     */
    private String esFechaValida(String fechaString) {
        if (fechaString.length() != 10) {
            return "Faltan datos";
        }

        // Verificar si el formato es DD/MM/AAAA usando una expresión regular
        if (!fechaString.matches("\\d{2}/\\d{2}/\\d{4}")) {
            return "No cumple con el formato";
        }

        int dia = Integer.parseInt(fechaString.substring(0,2), 10);
        int mes = Integer.parseInt(fechaString.substring(3,5), 10);
        int ano = Integer.parseInt(fechaString.substring(6), 10);

        // Verificar límites del mes
        if (mes < 1 || mes > 12) {
            return "Mes incorrecto";
        }
        // Verificar límites del día
        if (dia < 1 || dia > 31) {
            return "Dia incorrecto";
        }

        // Días máximos por mes
        int[] diasPorMes = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

        // Ajustar para años bisiestos
        boolean esBisiesto = (ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0);
        if (mes == 2 && esBisiesto) {
            diasPorMes[1] = 29;
        }

        if (dia > diasPorMes[mes-1]) {
            return "El día en ese mes no existe";
        }

        // Comprobamos que la fecha sea igual o posterior al día actual
        Calendar calendar = Calendar.getInstance();
        int diaActual = calendar.get(Calendar.DAY_OF_MONTH);
        int mesActual = calendar.get(Calendar.MONTH) + 1;
        int anoActual = calendar.get(Calendar.YEAR);

        if (ano < anoActual) {
            return "La fecha es anterior a la actual";
        }
        if (ano == anoActual) {
            if (mes < mesActual) {
                return "La fecha es anterior a la actual";
            }
            if (mes == mesActual) {
                if (dia < diaActual){
                    return "La fecha es anterior a la actual";
                }
                return ""; /* dia >= diaActual */
            }
            else /* mes > mesActual */ {
                return "";
            }
        } else /* ano > anoActual */ {
            return "";
        }
    }

    /**
     *  Comprueba si la fecha de salida es posterior a la fecha de entrada.
     */
    private boolean comprobarFechaPosterior(String fEnt, String fSal) {
        int diaEnt = Integer.parseInt(fEnt.substring(0,2), 10);
        int mesEnt = Integer.parseInt(fEnt.substring(3,5), 10);
        int anoEnt = Integer.parseInt(fEnt.substring(6), 10);

        int diaSal = Integer.parseInt(fSal.substring(0,2), 10);
        int mesSal = Integer.parseInt(fSal.substring(3,5), 10);
        int anoSal = Integer.parseInt(fSal.substring(6), 10);

        if (anoEnt > anoSal) return false;
        if (mesEnt > mesSal) return false;
        if (diaEnt >= diaSal) return false;

        return true;
    }

    /**
     *  Verifica que no haya parcelas duplicadas seleccionadas en la interfaz.
     */
    private boolean verificarDuplicadosParcelas() {
        Set<String> parcelIds = new HashSet<>();
        boolean hasDuplicate = false;

        for (int i = 0; i < contenedorParcelas.getChildCount(); i++) {
            View parcelaView = contenedorParcelas.getChildAt(i);
            Spinner spinnerParcela = parcelaView.findViewById(R.id.spinner_parcela);
            Parcela selectedParcel = (Parcela) spinnerParcela.getSelectedItem();
            if (selectedParcel != null && !parcelIds.add(selectedParcel.getId())) {
                hasDuplicate = true;
                break;
            }
        }

        if (hasDuplicate) {
            Toast.makeText(this, "No puede haber parcelas duplicadas en la selección.", Toast.LENGTH_LONG).show();
        }

        return !hasDuplicate; 
    }

    /**
     *  Guarda los cambios realizados en la reserva y actualiza las asociaciones con las parcelas.
     */
    private void guardarCambios() {
        int id = Integer.parseInt(mTextId.getText().toString());  

        String preNomCliente = mEditNomCliente.getText().toString().trim();
        if (preNomCliente.isEmpty()){
            mEditNomCliente.setError("El nombre no puede estar vacío");
            return;
        }
        String nomCliente = preNomCliente;

        String preNumMovil = mEditNumMovil.getText().toString().trim();
        if (preNumMovil.length() != 9) {
            mEditNumMovil.setError("El número móvil tiene que tener 9 dígitos");
            return;
        }
        int numMovil = Integer.parseInt(preNumMovil);

        String preFEnt = mEditFEnt.getText().toString().trim();
        String error = esFechaValida(preFEnt);
        if (!error.isEmpty()) {
            mEditFEnt.setError(error);
            return;
        }
        String fEnt = preFEnt;

        String preFSal = mEditFSal.getText().toString().trim();
        error = esFechaValida(preFSal);
        if (!error.isEmpty()) {
            mEditFSal.setError(error);
            return;
        }
        String fSal = preFSal;

        if (!comprobarFechaPosterior(fEnt, fSal)) {
            mEditFEnt.setError("La fecha de salida no es posterior a la de entrada");
            mEditFSal.setError("La fecha de salida no es posterior a la de entrada");
            return;
        }

        String preNumParcelas = mEditNumParcelas.getText().toString().trim();
        if (preNumParcelas.isEmpty()){
            mEditNumParcelas.setError("El número de parcelas no puede estar vacío");
            return;
        }
        int numParcelas = Integer.parseInt(preNumParcelas, 10);

        if (!verificarDuplicadosParcelas()) {
            return; // Si hay duplicados, detener el proceso de guardado
        }

        mReservaViewModel.getReservaById(id).observe(this, new Observer<Reserva>() {
            @Override
            public void onChanged(Reserva reserva) {
                if (reserva != null) {
                    // Actualizar la reserva con los datos modificados
                    reserva.setNomCliente(nomCliente);
                    reserva.setNumMovil(numMovil);
                    reserva.setFEnt(fEnt);
                    reserva.setFSal(fSal);
                    reserva.setNumParcelas(numParcelas);

                    // Guardar la reserva modificada en la base de datos
                    mReservaViewModel.update(reserva);

                    contenedorParcelas = findViewById(R.id.contenedorParcelas);

                    // Después de actualizar la reserva, actualizar las asociaciones
                    for (int i = 0; i < contenedorParcelas.getChildCount(); i++) {
                        View parcelaView = contenedorParcelas.getChildAt(i);
                        Spinner spinnerParcela = parcelaView.findViewById(R.id.spinner_parcela);
                        EditText editNumPersonas = parcelaView.findViewById(R.id.edit_num_personas);

                        if (spinnerParcela.getSelectedItemPosition() == -1) {
                            return;
                        }

                        Parcela parcelaSeleccionada = listaParcelas.get(spinnerParcela.getSelectedItemPosition());
                        int numOcupantes = 1;
                        String inputNumPersonas = editNumPersonas.getText().toString().trim();

                        if (!inputNumPersonas.isEmpty()) {
                            try {
                                numOcupantes = Integer.parseInt(inputNumPersonas);
                            } catch (NumberFormatException e) {
                                Log.e("ReservaEditActivity", "Número inválido, asignando 1 por defecto");
                            }
                        }

                        // Si la asociación ya existe, se actualiza
                        Asociacion asociacionExistente = encontrarAsociacionPorParcela(Integer.parseInt(parcelaSeleccionada.getId()));
                        if (asociacionExistente != null) {
                            asociacionExistente.setNumOcupantesPorParcela(numOcupantes);
                            mAsociacionViewModel.update(asociacionExistente);
                        } else {
                            // Si no existe, se inserta una nueva
                            Asociacion nuevaAsociacion = new Asociacion(reservaId, parcelaSeleccionada.getId(), numOcupantes);
                            mAsociacionViewModel.insert(nuevaAsociacion);
                        }
                    }
                    finish();

                } else {
                    mEditNomCliente.setError("NO SE HA ENCONTRADO LA RESERVA");
                }
            }
        });
    }

    private Asociacion encontrarAsociacionPorParcela(int parcelaId) {
        for (Asociacion asociacion : listaAsociaciones) {
            if (Integer.parseInt(asociacion.getParcelaId()) == parcelaId) {
                return asociacion;
            }
        }
        return null;
    }


    private class AdapterViewOnItemSelected implements android.widget.AdapterView.OnItemSelectedListener {
        private final TextView precioParcela;
        private final Spinner spinner;
        private final EditText editNumPersonas;

        public AdapterViewOnItemSelected(TextView precioParcela, Spinner spinner, EditText editNumPersonas) {
            this.precioParcela = precioParcela;
            this.spinner = spinner;
            this.editNumPersonas = editNumPersonas;
        }

        @Override
        public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
            Parcela parcelaSeleccionada = (Parcela) spinner.getItemAtPosition(position);
            int numPersonas;
            try {
                numPersonas = Integer.parseInt(editNumPersonas.getText().toString());
            } catch (NumberFormatException e) {
                numPersonas = 1; 
            }

            double precioTotalParcela = parcelaSeleccionada.getPrecioPorPersona() * numPersonas;
            precioParcela.setText(String.format(Locale.getDefault(), "%.2f€", precioTotalParcela));

            Asociacion asociacion = findAsociacionBySpinner(spinner);
            if (asociacion != null) {
                asociacion.setParcelaId(parcelaSeleccionada.getId());
                asociacion.setNumOcupantesPorParcela(numPersonas); 
                mAsociacionViewModel.update(asociacion); 
            }
        }

        @Override
        public void onNothingSelected(android.widget.AdapterView<?> parent) {}
    }

    private Asociacion findAsociacionBySpinner(Spinner spinner) {
        return null;
    }
}
