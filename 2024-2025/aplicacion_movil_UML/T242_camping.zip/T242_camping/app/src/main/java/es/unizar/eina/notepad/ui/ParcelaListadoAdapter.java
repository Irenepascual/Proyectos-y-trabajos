package es.unizar.eina.notepad.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import es.unizar.eina.notepad.R;
import es.unizar.eina.notepad.database.Parcela;

/**
 * Adaptador para mostrar un listado de parcelas en un RecyclerView.
 * Cada elemento del listado muestra:
 *  - Nombre de la parcela (ID)
 *  - Tamaño de la parcela
 *  - Precio por persona
 *  - Número máximo de ocupantes
 */
public class ParcelaListadoAdapter extends RecyclerView.Adapter<ParcelaListadoAdapter.ParcelaViewHolder> {

    // Lista de parcelas a mostrar en el RecyclerView
    private List<Parcela> mParcelas;

    /** Constructor por defecto del adaptador */
    public ParcelaListadoAdapter() {
    }

    /**
     * Método para actualizar la lista de parcelas en el adaptador.
     * @param parcelas Lista de parcelas a mostrar.
     */
    public void setParcelas(List<Parcela> parcelas) {
        mParcelas = parcelas;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ParcelaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_parcela_listado, parent, false);
        return new ParcelaViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ParcelaViewHolder holder, int position) {
        if (mParcelas != null) {
            Parcela current = mParcelas.get(position);
            holder.bind(current);
        }
    }

    @Override
    public int getItemCount() {
        return (mParcelas != null) ? mParcelas.size() : 0;
    }

    /** Clase interna que representa un ViewHolder para cada parcela en el RecyclerView */
    static class ParcelaViewHolder extends RecyclerView.ViewHolder {
        private final TextView nombreParcela;
        private final TextView tamanoParcela;
        private final TextView precioParcela;
        private final TextView numMaxOcupantesParcela;

        /** Constructor del ViewHolder que inicializa las vistas del elemento */
        public ParcelaViewHolder(@NonNull View itemView) {
            super(itemView);
            nombreParcela = itemView.findViewById(R.id.nombreParcela);
            tamanoParcela = itemView.findViewById(R.id.tamanoParcela);
            precioParcela = itemView.findViewById(R.id.precioParcela);
            numMaxOcupantesParcela = itemView.findViewById(R.id.numMaxOcupantesParcela);
        }

        /**
         * Método para vincular una parcela específica a las vistas del ViewHolder.
         * @param parcela Objeto de tipo Parcela con los datos a mostrar.
         */
        public void bind(final Parcela parcela) {
            nombreParcela.setText(parcela.getId());
            tamanoParcela.setText(String.valueOf(parcela.getTamano()));
            precioParcela.setText(String.valueOf(parcela.getPrecioPorPersona()));
            numMaxOcupantesParcela.setText(String.valueOf(parcela.getNumMaxOcupantes()));
        }
    }
}