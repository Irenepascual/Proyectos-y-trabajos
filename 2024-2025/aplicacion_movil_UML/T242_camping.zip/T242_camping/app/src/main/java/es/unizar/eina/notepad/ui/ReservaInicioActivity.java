package es.unizar.eina.notepad.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import es.unizar.eina.notepad.R;
import es.unizar.eina.notepad.database.Reserva;

import es.unizar.eina.notepad.send.SendAbstractionImpl;

/**
 * Clase principal para gestionar las reservas.
 * Muestra una lista de todas las reservas y ofrece opciones para editarlas,
 * eliminarlas, crear nuevas reservas, ver un listado detallado y enviar la información
 * de una reserva al móvil del cliente.
 */
public class ReservaInicioActivity extends AppCompatActivity {
    private ReservaViewModel mReservaViewModel;
    private RecyclerView mRecyclerView;
    private ReservaListAdapter mAdapter;

    Button mBotonVerListado;
    Button mBotonCrearReserva;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservas_inicio);

        // Inicializa la lista de reservas con opciones de editar, eliminar y enviar información.
        mRecyclerView = findViewById(R.id.recyclerview_reservas);
        mAdapter = new ReservaListAdapter(this::editReserva, this::deleteReserva, this::sendReserva);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Configura el ViewModel para observar cambios en las reservas.
        mReservaViewModel = new ViewModelProvider(this).get(ReservaViewModel.class);
        mReservaViewModel.getAllReservas().observe(this, mAdapter::setReservas);

        // Configura los botones de ver listado y crear reserva.
        mBotonVerListado = findViewById(R.id.button_ver_listado_reservas);
        mBotonCrearReserva = findViewById(R.id.button_crear_reserva);
        mBotonVerListado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { verListadoReservas();}
        });
        mBotonCrearReserva.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createReserva();
            }
        });
    }

    /**
     * Abre la pantalla de edición de una reserva con los datos actuales precargados.
     * @param reserva La reserva a editar.
     */
    private void editReserva(Reserva reserva) {
        Intent intent = new Intent(this, ReservaEditActivity.class);
        intent.putExtra("reserva_id", reserva.getId());
        intent.putExtra("reserva_nomCli", reserva.getNomCliente());
        intent.putExtra("reserva_numMovil", reserva.getNumMovil());
        intent.putExtra("reserva_fEnt", reserva.getFEnt());
        intent.putExtra("reserva_fSal", reserva.getFSal());
        intent.putExtra("reserva_numParcelas", reserva.getNumParcelas());
        startActivity(intent);
    }

    /**
     * Elimina una reserva específica.
     * @param reserva La reserva a eliminar.
     */
    private void deleteReserva(Reserva reserva) {
        mReservaViewModel.delete(reserva);
    }

    /**
     * Abre la pantalla para crear una nueva reserva.
     */
    private void createReserva() {
         Intent intent = new Intent(this, ReservaCreateActivity.class);
         startActivity(intent);
    }

    /**
     * Abre una pantalla con un listado detallado de reservas.
     * Permite ordenar las reservas por distintos criterios.
     */
    private void verListadoReservas() {
        Intent intent = new Intent(ReservaInicioActivity.this, ReservaListadoActivity.class);
        startActivity(intent);
    }

    /**
     * Envía la información de una reserva al móvil del cliente utilizando WhatsApp.
     * @param reserva La reserva cuya información se enviará.
     */
    private void sendReserva(Reserva reserva) {
        String telefono = String.valueOf(reserva.getNumMovil());
        String mensaje = "Reserva confirmada a nombre de: " + reserva.getNomCliente() +
                "\nFecha de entrada: " + reserva.getFEnt() +
                "\nFecha de salida: " + reserva.getFSal();

        String method = "WhatsApp";

        // Utiliza una implementación de envío para enviar el mensaje.
        SendAbstractionImpl sendAbstraction = new SendAbstractionImpl(this, method);

        // Llamar al método send
        sendAbstraction.send(telefono, mensaje);
    }
}