package es.unizar.eina.notepad.ui;
import es.unizar.eina.notepad.database.Parcela;
import es.unizar.eina.notepad.database.Asociacion;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.view.View;

import java.util.Locale;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import es.unizar.eina.notepad.R;
import es.unizar.eina.notepad.database.Reserva;

import android.text.TextWatcher;
import android.text.Editable;
import android.widget.LinearLayout;

import java.util.ArrayList;
import android.widget.AdapterView;
import java.util.List;
import java.util.Calendar;
import android.util.Log;


/**
 * Clase para la actividad de creación de reservas.
 * Permite al usuario ingresar información como el nombre del cliente, número móvil,
 * fechas de entrada y salida, y el número de parcelas a reservar.
 * Genera dinámicamente campos de entrada adicionales según el número de parcelas.
 */
public class ReservaCreateActivity extends AppCompatActivity {
    // Declaración de variables de UI y modelos de vista
    private EditText mEditNomCliente, mEditNumMovil, mEditFEnt, mEditFSal, mEditNumParcelas;
    private Button mButtonSave;
    private LinearLayout contenedorParcelas;
    private TextView totalPrecio;

    // Listas para manejar las parcelas disponibles y seleccionadas
    private List<Parcela> listaParcelas = new ArrayList<>();
    private List<Parcela> parcelasDisponibles = new ArrayList<>();

    // ViewModels para interactuar con las entidades de la base de datos
    private ParcelaViewModel mParcelaViewModel;
    private ReservaViewModel mReservaViewModel;
    private AsociacionViewModel mAsociacionViewModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reserva_create);

        // Inicialización de los ViewModels
        mAsociacionViewModel = new ViewModelProvider(this).get(AsociacionViewModel.class);
        mParcelaViewModel = new ViewModelProvider(this).get(ParcelaViewModel.class);
        mAsociacionViewModel = new ViewModelProvider(this).get(AsociacionViewModel.class);

        // Inicialización de vistas
        contenedorParcelas = findViewById(R.id.contenedorParcelas);
        totalPrecio = findViewById(R.id.total_precio);

        mParcelaViewModel.getAllParcelas().observe(this, parcelas -> {
            if (parcelas != null) {
                listaParcelas = parcelas;
                actualizarParcelasDisponibles();
            }
        });

        mEditNomCliente = findViewById(R.id.create_nomCliente);
        mEditNumMovil = findViewById(R.id.create_numMovil);
        mEditFEnt = findViewById(R.id.create_fEnt);
        mEditFSal = findViewById(R.id.create_fSal);
        mEditNumParcelas = findViewById(R.id.create_numParcelas);
        mButtonSave = findViewById(R.id.button_save);

        mEditFEnt.addTextChangedListener(new TextWatcher() {
            private String formatoAnterior = "";

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                formatoAnterior = s.toString();
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // No es necesario manejar esta parte
            }

            @Override
            public void afterTextChanged(Editable s) {
                String textoActual = s.toString();

                if (!textoActual.equals(formatoAnterior)) {
                    String textoFormateado = formatearFecha(textoActual);
                    formatoAnterior = textoFormateado;
                    mEditFEnt.removeTextChangedListener(this);
                    mEditFEnt.setText(textoFormateado);
                    mEditFEnt.setSelection(textoFormateado.length());
                    mEditFEnt.addTextChangedListener(this);

                    actualizarParcelasDisponibles();
                }
            }
        });

        mEditFSal.addTextChangedListener(new TextWatcher() {
            private String formatoAnterior = "";

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                formatoAnterior = s.toString();
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // No es necesario manejar esta parte
            }

            @Override
            public void afterTextChanged(Editable s) {
                String textoActual = s.toString();

                if (!textoActual.equals(formatoAnterior)) {
                    String textoFormateado = formatearFecha(textoActual);
                    formatoAnterior = textoFormateado;
                    mEditFSal.removeTextChangedListener(this);
                    mEditFSal.setText(textoFormateado);
                    mEditFSal.setSelection(textoFormateado.length());
                    mEditFSal.addTextChangedListener(this);

                    actualizarParcelasDisponibles();
                }
            }
        });

        mEditNumParcelas.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (!s.toString().isEmpty()) {
                    actualizarParcelasDisponibles();
                }
            }
        });


        mReservaViewModel = new ViewModelProvider(this).get(ReservaViewModel.class);

        // Configuramos el evento del botón para guardar los cambios
        mButtonSave.setOnClickListener(v -> saveReserva());
    }

    /**
     * Actualiza la lista de parcelas disponibles según las fechas seleccionadas
     * y otras restricciones de disponibilidad.
     */
    private void actualizarParcelasDisponibles() {
        String fechaEntrada = mEditFEnt.getText().toString().trim();
        String fechaSalida = mEditFSal.getText().toString().trim();

        if (fechaEntrada.length() == 10 && fechaSalida.length() == 10) {
            parcelasDisponibles = new ArrayList<>(listaParcelas);

            // Filtrar parcelas ocupadas en las fechas seleccionadas
            mAsociacionViewModel.getAllAsociaciones().observe(this, todasLasAsociaciones -> {
                List<Parcela> parcelasFiltradas = new ArrayList<>(parcelasDisponibles);

                for (Parcela parcela : parcelasDisponibles) {
                    for (Asociacion asociacion : todasLasAsociaciones) {
                        if (parcela.getId().equals(asociacion.getParcelaId())) {
                            mReservaViewModel.getReservaById(asociacion.getReservaId()).observe(this, reserva -> {
                                if (reserva != null && fechasSeSolapan(fechaEntrada, fechaSalida, reserva.getFEnt(), reserva.getFSal())) {
                                    parcelasFiltradas.remove(parcela);
                                }
                            });
                        }
                    }
                }
                parcelasDisponibles = parcelasFiltradas;
            });

            if (parcelasDisponibles.isEmpty()) {
                Toast.makeText(this, "No hay parcelas disponibles para las fechas seleccionadas.", Toast.LENGTH_SHORT).show();
            }
        }

        actualizarUIParcelas();
        actualizarPrecioTotal();
    }

    // Comprueba dadas 2 periodos de tiempo (con su inicio y fin) si hay solape
    private boolean fechasSeSolapan(String fEnt1, String fSal1, String fEnt2, String fSal2) {
        int inicio1 = convertirFechaAInt(fEnt1);
        int fin1 = convertirFechaAInt(fSal1);
        int inicio2 = convertirFechaAInt(fEnt2);
        int fin2 = convertirFechaAInt(fSal2);

        return !(fin1 <= inicio2 || fin2 <= inicio1);
    }

    private int convertirFechaAInt(String fecha) {
        String[] partes = fecha.split("/");
        return Integer.parseInt(partes[2] + partes[1] + partes[0]);
    }

    /**
    * Actualiza la interfaz de usuario para mostrar las parcelas seleccionadas.
    * Crea dinámicamente vistas para que el usuario seleccione parcelas y especifique el número de personas.
    */
    private void actualizarUIParcelas() {
        // Limpia las vistas anteriores del contenedor para evitar duplicados
        contenedorParcelas.removeAllViews();

        // Verifica si el número de parcelas ingresado es válido
        String numParcelasStr = mEditNumParcelas.getText().toString().trim();
        if (numParcelasStr.isEmpty()) {
            return;
        }

        int numeroParcelas;
        // Intenta convertir el texto ingresado en un número entero
        try {
            numeroParcelas = Integer.parseInt(numParcelasStr);
        } catch (NumberFormatException e) {
            mEditNumParcelas.setError("Por favor, introduce un número válido.");
            return;
        }

        if (numeroParcelas < 0) {
            mEditNumParcelas.setError("El número de parcelas no puede ser negativo.");
            return;
        }

        // Verifica si hay parcelas disponibles en la lista
        if (listaParcelas.isEmpty()) {
            totalPrecio.setText("No hay parcelas disponibles.");
            return;
        }

        // Crea dinámicamente las vistas para seleccionar parcelas y especificar ocupantes
        for (int i = 0; i < numeroParcelas; i++) {
            View parcelaView = getLayoutInflater().inflate(R.layout.item_asociacion_2, contenedorParcelas, false);

            // Obtiene referencias a los elementos de la vista
            Spinner spinnerParcelas = parcelaView.findViewById(R.id.spinner_parcela);
            EditText editNumPersonas = parcelaView.findViewById(R.id.edit_num_personas);
            TextView precioParcela = parcelaView.findViewById(R.id.precio_parcela);

            // Configura el Spinner para mostrar las parcelas disponibles
            ArrayAdapter<Parcela> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, parcelasDisponibles);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerParcelas.setAdapter(adapter);

            // Listener para actualizar el precio cuando se selecciona una parcela
            spinnerParcelas.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    Parcela parcelaSeleccionada = listaParcelas.get(position);
                    precioParcela.setText(String.format(Locale.getDefault(), "%.2f€", parcelaSeleccionada.getPrecioPorPersona()));
                    actualizarPrecioTotal();
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {}
            });

            // TextWatcher para recalcular el precio total cuando se modifica el número de personas
            editNumPersonas.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {}

                @Override
                public void afterTextChanged(Editable s) {
                    actualizarPrecioTotal(); // Recalcular el precio total
                }
            });

            // Añadir la vista al contenedor
            contenedorParcelas.addView(parcelaView);
        }

        // Calcula y muestra el precio basado en la selección actual
        actualizarPrecioTotal();
    }

    /**
     * Calcula el precio total de la reserva en función de las parcelas seleccionadas
     * y el número de ocupantes por parcela.
     */
    private void actualizarPrecioTotal() {
        double precioTotal = 0.0;

        for (int i = 0; i < contenedorParcelas.getChildCount(); i++) {
            View parcelaView = contenedorParcelas.getChildAt(i);
            Spinner spinnerParcelas = parcelaView.findViewById(R.id.spinner_parcela);
            EditText editNumPersonas = parcelaView.findViewById(R.id.edit_num_personas);

            // Obtener la parcela seleccionada
            if (spinnerParcelas.getAdapter() != null) {
                int posicion = spinnerParcelas.getSelectedItemPosition();
                if (posicion >= 0) {
                    Parcela parcelaSeleccionada = listaParcelas.get(posicion);

                    // Obtener el número de personas
                    int numPersonas = 0; // Valor por defecto
                    String inputNumPersonas = editNumPersonas.getText().toString().trim();
                    if (!inputNumPersonas.isEmpty()) {
                        try {
                            numPersonas = Integer.parseInt(inputNumPersonas);
                        } catch (NumberFormatException e) {
                            Log.e("ReservaCreateActivity", "Número de personas inválido, usando valor por defecto.");
                        }
                    }

                    // Calcular el precio total: precioPorPersona * número de personas
                    precioTotal += parcelaSeleccionada.getPrecioPorPersona() * numPersonas;
                }
            }
        }

        // Actualizar el precio total en la interfaz
        totalPrecio.setText(String.format(Locale.getDefault(), "El precio será: %.2f€", precioTotal));
    }

    /**
    * Formatea una fecha ingresada por el usuario eliminando caracteres no numéricos
    * y añadiendo separadores (/) en las posiciones correctas.
    * @param texto La fecha en formato libre ingresada por el usuario.
    * @return La fecha formateada en formato DD/MM/AAAA.
    */
    private String formatearFecha(String texto) {
        texto = texto.replaceAll("[^\\d]", ""); // Elimina todo lo que no sea un dígito

        StringBuilder resultado = new StringBuilder();
        int longitud = texto.length();

        for (int i = 0; i < longitud; i++) {
            if (i == 2 || i == 4) {             // Añade "/" después del día y el mes
                resultado.append("/");
            }
            resultado.append(texto.charAt(i));
        }

        return resultado.toString();
    }

    /**
    * Verifica si una fecha es válida en términos de formato, valores y límites.
    * @param fechaString La fecha en formato DD/MM/AAAA.
    * @return Un mensaje de error si la fecha es inválida, o una cadena vacía si es válida.
    */
    private String esFechaValida(String fechaString) {
        if (fechaString.length() != 10) {
            return "Faltan datos (formato DD/MM/AAAA)";
        }

        // Verificar si el formato es DD/MM/AAAA usando una expresión regular
        if (!fechaString.matches("\\d{2}/\\d{2}/\\d{4}")) {
            return "No cumple con el formato";
        }

        int dia = Integer.parseInt(fechaString.substring(0,2), 10);
        int mes = Integer.parseInt(fechaString.substring(3,5), 10);
        int ano = Integer.parseInt(fechaString.substring(6), 10);

        // Verificar límites del mes
        if (mes < 1 || mes > 12) {
            return "Mes incorrecto";
        }
        // Verificar límites del día
        if (dia < 1 || dia > 31) {
            return "Dia incorrecto";
        }

        // Días máximos por mes
        int[] diasPorMes = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

        // Ajustar para años bisiestos
        boolean esBisiesto = (ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0);
        if (mes == 2 && esBisiesto) {
            diasPorMes[1] = 29;
        }

        if (dia > diasPorMes[mes-1]) {
            return "El día en ese mes no existe";
        }

        // Comprobamos que la fecha sea igual o posterior al día actual
        Calendar calendar = Calendar.getInstance();
        int diaActual = calendar.get(Calendar.DAY_OF_MONTH);
        int mesActual = calendar.get(Calendar.MONTH) + 1;
        int anoActual = calendar.get(Calendar.YEAR);

        if (ano < anoActual) {
            return "La fecha es anterior a la actual";
        }
        if (ano == anoActual) {
            if (mes < mesActual) {
                return "La fecha es anterior a la actual";
            }
            if (mes == mesActual) {
                if (dia < diaActual){
                    return "La fecha es anterior a la actual";
                }
                return ""; /* dia >= diaActual */
            }
            else /* mes > mesActual */ {
                return "";
            }
        } else /* ano > anoActual */ {
            return "";
        }
    }

    /**
    * Verifica si la fecha de salida es posterior a la fecha de entrada.
    * @param fEnt Fecha de entrada en formato DD/MM/AAAA.
    * @param fSal Fecha de salida en formato DD/MM/AAAA.
    * @return true si la fecha de salida es posterior a la de entrada, false en caso contrario.
    */
    private boolean comprobarFechaPosterior(String fEnt, String fSal) {
        int diaEnt = Integer.parseInt(fEnt.substring(0,2), 10);
        int mesEnt = Integer.parseInt(fEnt.substring(3,5), 10);
        int anoEnt = Integer.parseInt(fEnt.substring(6), 10);

        int diaSal = Integer.parseInt(fSal.substring(0,2), 10);
        int mesSal = Integer.parseInt(fSal.substring(3,5), 10);
        int anoSal = Integer.parseInt(fSal.substring(6), 10);

        if (anoEnt > anoSal) return false;
        if (mesEnt > mesSal) return false;
        if (diaEnt >= diaSal) return false;

        return true;
    }

    /**
    * Procedimiento para crear una nueva reserva, guardar los datos en la base de datos,
    * y asociar las parcelas seleccionadas a la reserva.
    */
    private void saveReserva() {
        // Validación y obtención del nombre del cliente.
        String preNomCliente = mEditNomCliente.getText().toString().trim();
        if (preNomCliente.isEmpty()){
            mEditNomCliente.setError("El nombre no puede ser nulo");
        }
        String nomCliente = preNomCliente;

        // Validación y obtención del número móvil.
        String preNumMovil = mEditNumMovil.getText().toString().trim();
        if (preNumMovil.length() != 9) {
            mEditNumMovil.setError("El número móvil tiene que tener 9 dígitos");
            return;
        }
        int numMovil = Integer.parseInt(preNumMovil);

        // Validación y obtención de la fecha de entrada.
        String preFEnt = mEditFEnt.getText().toString().trim();
        String error = esFechaValida(preFEnt);
        if (!error.isEmpty()) {
            mEditFEnt.setError(error);
            return;
        }
        String fEnt = preFEnt;

        // Validación y obtención de la fecha de salida.
        String preFSal = mEditFSal.getText().toString().trim();
        error = esFechaValida(preFSal);
        if (!error.isEmpty()) {
            mEditFSal.setError(error);
            return;
        }
        String fSal = preFSal;

        // Verifica que la fecha de salida sea posterior a la de entrada.
        if (!comprobarFechaPosterior(fEnt, fSal)) {
            mEditFSal.setError("La fecha de salida no es posterior a la de entrada");
            return;
        }

        // Validación y obtención del número de parcelas.
        String preNumParcelas = mEditNumParcelas.getText().toString().trim();
        if (preNumParcelas.isEmpty()){
            mEditNumParcelas.setError("El número de parcelas no puede estar vacío");
            return;
        }
        int numParcelas = Integer.parseInt(preNumParcelas);

        // Creación del objeto Reserva.
        Reserva reserva = new Reserva(nomCliente, numMovil, fEnt, fSal, numParcelas);
        mReservaViewModel.insert(reserva);

        // Observa el ID de la reserva insertada para realizar las asociaciones.
        mReservaViewModel.getInsertedReservaId().observe(this, id -> {
            if (id > 0) {

                // Asocia las parcelas seleccionadas a la reserva.
                for (int i = 0; i < contenedorParcelas.getChildCount(); i++) {
                    View parcelaView = contenedorParcelas.getChildAt(i);
                    Spinner spinnerParcelas = parcelaView.findViewById(R.id.spinner_parcela);
                    int posicion = spinnerParcelas.getSelectedItemPosition();
                    Parcela parcelaSeleccionada = listaParcelas.get(posicion);
                    EditText editNumPersonas = parcelaView.findViewById(R.id.edit_num_personas);

                    int numOcupantes = 0;

                    String inputNumPersonas = editNumPersonas.getText().toString().trim();
                    if (!inputNumPersonas.isEmpty()) {
                        try {
                            numOcupantes = Integer.parseInt(inputNumPersonas);
                        } catch (NumberFormatException e) {
                            Log.e("ReservaCreateActivity", "Número de personas inválido, usando valor por defecto.");
                        }
                    }
                    // Crear la asociación con el ID de la reserva
                    Asociacion asociacion = new Asociacion(id.intValue(), parcelaSeleccionada.getId(), numOcupantes);
                    mAsociacionViewModel.insert(asociacion);
                }
                Log.d("ReservaCreateActivity", "Reserva y asociaciones guardadas correctamente.");
            }
        });

        // Finaliza la actividad.
        finish();
    }
}
