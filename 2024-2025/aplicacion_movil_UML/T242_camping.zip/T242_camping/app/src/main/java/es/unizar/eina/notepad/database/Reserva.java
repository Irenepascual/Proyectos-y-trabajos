package es.unizar.eina.notepad.database;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Clase anotada como entidad que representa una reserva en el sistema de base de datos.
 * Cada reserva consta de:
 * - Identificador único (id).
 * - Nombre del cliente asociado a la reserva (nomCliente).
 * - Número móvil del cliente (numMovil).
 * - Fecha de entrada (fEnt).
 * - Fecha de salida (fSal).
 * - Número de parcelas reservadas (numParcelas).
 */
@Entity(tableName = "reserva")
public class Reserva {
    // ID autogenerado para cada reserva
    @PrimaryKey(autoGenerate = true)
    @NonNull
    @ColumnInfo(name = "id")
    private int id;

    // Nombre del cliente
    @NonNull
    @ColumnInfo(name = "nomCliente")
    private String nomCliente;

    // Número móvil del cliente
    @NonNull
    @ColumnInfo(name = "numMovil")
    private int numMovil;

    // Fecha de entrada de la reserva
    @NonNull
    @ColumnInfo(name = "fEnt")
    private String fEnt;

    // Fecha de salida de la reserva
    @NonNull
    @ColumnInfo(name = "fSal")
    private String fSal;

    // Número de parcelas reservadas
    @NonNull
    @ColumnInfo(name = "numParcelas")
    private int numParcelas;

    /**
     * Constructor de la clase Reserva.
     * @param nomCliente Nombre del cliente asociado a la reserva.
     * @param numMovil Número móvil del cliente.
     * @param fEnt Fecha de entrada de la reserva en formato DD/MM/AAAA.
     * @param fSal Fecha de salida de la reserva en formato DD/MM/AAAA.
     * @param numParcelas Número de parcelas reservadas.
     */
    public Reserva(@NonNull String nomCliente, @NonNull int numMovil,
                   @NonNull String fEnt, @NonNull String fSal, @NonNull int numParcelas) {
        this.nomCliente = nomCliente;
        this.numMovil = numMovil;
        this.fEnt = fEnt;
        this.fSal = fSal;
        this.numParcelas = numParcelas;
    }

    /**
     * Devuelve el identificador único de la reserva.
     * @return ID de la reserva.
     */
    public int getId(){
        return this.id;
    }


    /**
     * Permite actualizar el identificador único de la reserva.
     * @param id Nuevo identificador de la reserva.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Devuelve el nombre del cliente asociado a la reserva.
     * @return Nombre del cliente.
     */
    public String getNomCliente(){
        return this.nomCliente;
    }

    /**
     * Permite actualizar el nombre del cliente asociado a la reserva.
     * @param nomCliente Nuevo nombre del cliente.
     */
    public void setNomCliente(String nomCliente) {
        this.nomCliente = nomCliente;
    }

    /**
     * Devuelve el número móvil del cliente asociado a la reserva.
     * @return Número móvil del cliente.
     */
    public int getNumMovil(){
        return this.numMovil;
    }

    /** Permite actualizar el número móvil de una reserva */
    public void setNumMovil(int numMovil) {
        this.numMovil = numMovil;
    }

    /** Devuelve la fecha de entrada de la reserva */
    public String getFEnt(){
        return this.fEnt;
    }

    /** Permite actualizar la fecha de entrada de una reserva */
    public void setFEnt(String fEnt) {
        this.fEnt = fEnt;
    }

    /** Devuelve la fecha de salida de la reserva */
    public String getFSal(){
        return this.fSal;
    }

    /** Permite actualizar la fecha de salida de una reserva */
    public void setFSal(String fSal) {
        this.fSal = fSal;
    }

    /** Devuelve el número de parcelas de la reserva */
    public int getNumParcelas(){
        return this.numParcelas;
    }

    /** Permite actualizar el número de parcelas de una reserva */
    public void setNumParcelas(int numParcelas) {
        this.numParcelas = numParcelas;
    }
}
