package es.unizar.eina.notepad.database;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Clase anotada como entidad que representa una parcela.
 * Cada parcela tiene un identificador único (id), un tamaño (tamano),
 * características de disponibilidad (agua y luz), un número máximo de ocupantes,
 * y un precio por persona.
 */
@Entity(tableName = "parcela")
public class Parcela {
    // Identificador único de la parcela (clave primaria, no autogenerada)
    @PrimaryKey(autoGenerate = false)
    @NonNull
    @ColumnInfo(name = "id")
    private String id;

    // Tamaño de la parcela en metros cuadrados
    @NonNull
    @ColumnInfo(name = "tamano")
    private double tamano;

    // Indica si la parcela dispone de agua
    @NonNull
    @ColumnInfo(name = "disponibilidadAgua")
    private boolean disponibilidadAgua;

    // Indica si la parcela dispone de luz
    @NonNull
    @ColumnInfo(name = "disponibilidadLuz")
    private boolean disponibilidadLuz;

    // Número máximo de ocupantes permitidos en la parcela
    @NonNull
    @ColumnInfo(name = "numMaxOcupantes")
    private int numMaxOcupantes;

    // Precio por persona para usar la parcela
    @NonNull
    @ColumnInfo(name = "precioPorPersona")
    private double precioPorPersona;

    /**
     * Constructor de la clase Parcela.
     * Inicializa todos los atributos de la parcela.
     *
     * @param id Identificador único de la parcela.
     * @param tamano Tamaño de la parcela en metros cuadrados.
     * @param disponibilidadAgua Indica si hay disponibilidad de agua.
     * @param disponibilidadLuz Indica si hay disponibilidad de luz.
     * @param numMaxOcupantes Número máximo de ocupantes permitidos.
     * @param precioPorPersona Precio por persona para usar la parcela.
     */
    public Parcela(@NonNull String id, @NonNull double tamano,
                   @NonNull boolean disponibilidadAgua, @NonNull boolean disponibilidadLuz,
                   @NonNull int numMaxOcupantes, @NonNull double precioPorPersona) {
        this.id = id;
        this.tamano = tamano;
        this.disponibilidadAgua = disponibilidadAgua;
        this.disponibilidadLuz = disponibilidadLuz;
        this.numMaxOcupantes = numMaxOcupantes;
        this.precioPorPersona = precioPorPersona;
    }

    /**
     * Devuelve el identificador único de la parcela.
     *
     * @return El identificador de la parcela como un String.
     */
    public String getId() {
        return this.id;
    }

    /**
     * Actualiza el identificador único de la parcela.
     *
     * @param id Nuevo identificador de la parcela.
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Devuelve el tamaño de la parcela en metros cuadrados.
     *
     * @return El tamaño de la parcela como un double.
     */
    public double getTamano() {
        return this.tamano;
    }

    /**
     * Actualiza el tamaño de la parcela.
     *
     * @param tamano Nuevo tamaño de la parcela en metros cuadrados.
     */
    public void setTamano(double tamano) {
        this.tamano = tamano;
    }

    /**
     * Devuelve si la parcela tiene disponibilidad de agua.
     *
     * @return true si la parcela dispone de agua, false en caso contrario.
     */
    public boolean getDisponibilidadAgua() {
        return this.disponibilidadAgua;
    }

    /**
     * Actualiza la disponibilidad de agua de la parcela.
     *
     * @param disponibilidadAgua Nuevo estado de disponibilidad de agua (true/false).
     */
    public void setDisponibilidadAgua(boolean disponibilidadAgua) {
        this.disponibilidadAgua = disponibilidadAgua;
    }

    /**
     * Devuelve si la parcela tiene disponibilidad de luz.
     *
     * @return true si la parcela dispone de luz, false en caso contrario.
     */
    public boolean getDisponibilidadLuz() {
        return this.disponibilidadLuz;
    }

    /**
     * Actualiza la disponibilidad de luz de la parcela.
     *
     * @param disponibilidadLuz Nuevo estado de disponibilidad de luz (true/false).
     */
    public void setDisponibilidadLuz(boolean disponibilidadLuz) {
        this.disponibilidadLuz = disponibilidadLuz;
    }

    /**
     * Devuelve el número máximo de ocupantes permitidos en la parcela.
     *
     * @return El número máximo de ocupantes como un entero.
     */
    public int getNumMaxOcupantes() {
        return this.numMaxOcupantes;
    }

    /**
     * Actualiza el número máximo de ocupantes permitidos en la parcela.
     *
     * @param numMaxOcupantes Nuevo número máximo de ocupantes.
     */
    public void setNumMaxOcupantes(int numMaxOcupantes) {
        this.numMaxOcupantes = numMaxOcupantes;
    }

    /**
     * Devuelve el precio por persona de la parcela.
     *
     * @return El precio por persona como un double.
     */
    public double getPrecioPorPersona() {
        return this.precioPorPersona;
    }

    /**
     * Actualiza el precio por persona de la parcela.
     *
     * @param precioPorPersona Nuevo precio por persona.
     */
    public void setPrecioPorPersona(double precioPorPersona) {
        this.precioPorPersona = precioPorPersona;
    }

    /**
     * Devuelve una representación en cadena de la parcela.
     * Incluye el identificador y el precio por persona.
     *
     * @return Una cadena con el formato "id (precioPorPersona€)".
     */
    @Override
    public String toString() {
        return this.id + " (" + this.precioPorPersona + "€)";
    }
}