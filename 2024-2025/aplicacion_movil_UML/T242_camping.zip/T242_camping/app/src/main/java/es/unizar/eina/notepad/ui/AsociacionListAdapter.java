package es.unizar.eina.notepad.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import es.unizar.eina.notepad.R;
import es.unizar.eina.notepad.database.Asociacion;
import es.unizar.eina.notepad.database.Parcela;

/**
 * Adaptador para gestionar y mostrar las asociaciones en un RecyclerView.
 * Cada ítem en el RecyclerView representa una asociación que vincula una parcela con una reserva.
 */
public class AsociacionListAdapter extends RecyclerView.Adapter<AsociacionListAdapter.AsociacionViewHolder> {

    private List<Asociacion> mAsociaciones;
    private final OnEditClickListener mEditListener;
    private final OnDeleteClickListener mDeleteListener;
    private List<Parcela> mParcelas;


    /**
     * Interfaz para manejar eventos de edición en una asociación.
     */
    public interface OnEditClickListener {
        void onEditClick(Asociacion asociacion);
    }

    /**
     * Interfaz para manejar eventos de eliminación en una asociación.
     */
    public interface OnDeleteClickListener {
        void onDeleteClick(Asociacion asociacion);
    }

    /**
     * Constructor del adaptador de asociaciones.
     * @param editListener Listener para manejar la acción de editar.
     * @param deleteListener Listener para manejar la acción de eliminar.
     * @param parcelas Lista de parcelas disponibles.
     */
    public AsociacionListAdapter(OnEditClickListener editListener, OnDeleteClickListener deleteListener, List<Parcela> parcelas) {
        mEditListener = editListener;
        mDeleteListener = deleteListener;
        mParcelas = parcelas;
    }

    /**
     * Actualiza la lista de asociaciones y notifica los cambios al adaptador.
     * @param asociaciones Lista de asociaciones actualizada.
     */
    public void setAsociaciones(List<Asociacion> asociaciones) {
        mAsociaciones = asociaciones;
        notifyDataSetChanged();
    }

    /**
     * Obtiene una parcela por su identificador.
     * @param parcelaId ID de la parcela.
     * @return Objeto Parcela correspondiente al ID, o null si no se encuentra.
     */
    private Parcela obtenerParcelaPorId(String parcelaId) {
        for (Parcela parcela : mParcelas) {
            if (parcela.getId().equals(parcelaId)) {
                return parcela;
            }
        }
        return null; // Si no se encuentra la parcela devuelve null
    }

    @NonNull
    @Override
    public AsociacionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_asociacion, parent, false);
        return new AsociacionViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull AsociacionViewHolder holder, int position) {
        if (mAsociaciones != null) {
            Asociacion current = mAsociaciones.get(position);

            // Obtiene la información de la parcela
            Parcela parcela = obtenerParcelaPorId(current.getParcelaId());

            if (parcela != null) {
                holder.parcelaIdView.setText("Nombre: " + parcela.getId());
                holder.parcelaPrecioView.setText("Precio: " + parcela.getPrecioPorPersona() + "€");
            } else {
                holder.parcelaIdView.setText("Nombre: N/A");
                holder.parcelaPrecioView.setText("Precio: N/A");
            }

            holder.numOcupantesView.setText("Número ocupantes: " + current.getNumOcupantesPorParcela());

            // Configura el botón de eliminar
            holder.buttonEdit.setOnClickListener(v -> mEditListener.onEditClick(current));
            holder.buttonDelete.setOnClickListener(v -> mDeleteListener.onDeleteClick(current));
        }
    }

    @Override
    public int getItemCount() {
        return (mAsociaciones != null) ? mAsociaciones.size() : 0;
    }

    /**
     * Clase ViewHolder para representar cada ítem del RecyclerView.
     * Mantiene referencias a las vistas de cada ítem.
     */
    static class AsociacionViewHolder extends RecyclerView.ViewHolder {
        private final TextView parcelaIdView;
        private final TextView numOcupantesView;
        private final TextView parcelaPrecioView;
        private final ImageButton buttonEdit;
        private final ImageButton buttonDelete;

        /**
         * Constructor del ViewHolder.
         * @param itemView Vista del ítem del RecyclerView.
         */
        public AsociacionViewHolder(@NonNull View itemView) {
            super(itemView);
            parcelaIdView = itemView.findViewById(R.id.textViewParcela);
            numOcupantesView = itemView.findViewById(R.id.textView_num_ocupantes);
            parcelaPrecioView = itemView.findViewById(R.id.textViewPrecio);
            buttonEdit = itemView.findViewById(R.id.buttonEdit);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }

        /**
         * Asigna valores y listeners a las vistas del ítem.
         * @param asociacion Asociación a mostrar en el ítem.
         * @param editListener Listener para el botón de editar.
         * @param deleteListener Listener para el botón de eliminar.
         */
        public void bind(final Asociacion asociacion, final OnEditClickListener editListener, final OnDeleteClickListener deleteListener) {
            parcelaIdView.setText(asociacion.getParcelaId());
            numOcupantesView.setText(String.valueOf(asociacion.getNumOcupantesPorParcela()));

            buttonEdit.setOnClickListener(v -> editListener.onEditClick(asociacion));
            buttonDelete.setOnClickListener(v -> deleteListener.onDeleteClick(asociacion));
        }
    }
}
