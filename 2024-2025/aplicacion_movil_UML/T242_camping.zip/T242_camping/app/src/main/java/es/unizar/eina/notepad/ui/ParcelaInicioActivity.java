package es.unizar.eina.notepad.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import es.unizar.eina.notepad.R;
import es.unizar.eina.notepad.database.Parcela;

/**
 * Pantalla principal para la gestión de parcelas.
 * Muestra un listado de todas las parcelas existentes y permite realizar las siguientes acciones:
 * - Editar o eliminar parcelas existentes.
 * - Crear una nueva parcela.
 * - Ver un listado detallado y ordenado de las parcelas por distintos criterios.
 */
public class ParcelaInicioActivity extends AppCompatActivity {

    private ParcelaViewModel mParcelaViewModel;
    private RecyclerView mRecyclerView;
    private ParcelaListAdapter mAdapter;

    Button mBotonVerListadoParcelas;
    Button mBotonCrearParcela;

    /**
     * Método llamado al crear la actividad.
     * Inicializa la interfaz de usuario y configura los eventos.
     * @param savedInstanceState Estado previamente guardado de la actividad, si existe.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parcelas_inicio);

        mRecyclerView = findViewById(R.id.recyclerview_parcelas);
        mAdapter = new ParcelaListAdapter(this::editParcela, this::deleteParcela);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        mParcelaViewModel = new ViewModelProvider(this).get(ParcelaViewModel.class);
        mParcelaViewModel.getAllParcelas().observe(this, mAdapter::setParcelas);

        mBotonVerListadoParcelas = findViewById(R.id.button_ver_listado);
        mBotonCrearParcela = findViewById(R.id.button_crear_parcela);

        // Configuración de los eventos para los botones
        mBotonVerListadoParcelas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { verListadoParcelas();}
        });

        mBotonCrearParcela.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createParcela();
            }
        });
    }

    /**
     * Procedimiento que lanza la pantalla para editar una parcela.
     * Los datos actuales de la parcela se pasan como parámetros al Intent.
     * @param parcela La parcela seleccionada para editar.
     */
    private void editParcela(Parcela parcela) {
        Intent intent = new Intent(this, ParcelaEditActivity.class);
        intent.putExtra("parcela_id", parcela.getId());
        intent.putExtra("parcela_tamano", parcela.getTamano());
        intent.putExtra("parcela_disponibilidad_agua", parcela.getDisponibilidadAgua());
        intent.putExtra("parcela_disponibilidad_luz", parcela.getDisponibilidadLuz());
        intent.putExtra("parcela_num_max_ocupantes", parcela.getNumMaxOcupantes());
        intent.putExtra("parcela_precio_por_persona", parcela.getPrecioPorPersona());
        startActivity(intent);
    }

    /**
     * Procedimiento que elimina una parcela de la base de datos.
     * @param parcela La parcela seleccionada para eliminar.
     */
    private void deleteParcela(Parcela parcela) {
        mParcelaViewModel.delete(parcela);
    }

    /**
     * Procedimiento que lanza la pantalla para crear una nueva parcela.
     */
    private void createParcela() {
        Intent intent = new Intent(this, ParcelaCreateActivity.class);
        startActivity(intent);
    }

    /**
     * Procedimiento que lanza la pantalla para ver el listado detallado de parcelas.
     * Permite ordenar el listado por diferentes criterios como el identificador, precio o número de ocupantes.
     */
    private void verListadoParcelas() {
        Intent intent = new Intent(this, ParcelaListadoActivity.class);
        startActivity(intent);
    }
}


