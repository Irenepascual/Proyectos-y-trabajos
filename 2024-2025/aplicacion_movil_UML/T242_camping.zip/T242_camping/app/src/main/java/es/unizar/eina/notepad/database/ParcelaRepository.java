package es.unizar.eina.notepad.database;

import android.app.Application;
import android.util.Log;

import androidx.lifecycle.LiveData;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Repositorio que centraliza el acceso a los datos relacionados con las parcelas.
 * Gestiona la interacción con la base de datos a través de ParcelaDao y CampingRoomDatabase.
 */
public class ParcelaRepository {

    // DAO para acceder a las operaciones relacionadas con las parcelas
    private final ParcelaDao mParcelaDao;

    // Listas observables con las parcelas, que se actualizan automáticamente cuando cambian los datos
    private final LiveData<List<Parcela>> mAllParcelas;
    private final LiveData<List<Parcela>> mOrderedParcelasID;
    private final LiveData<List<Parcela>> mOrderedParcelasPRECIO;
    private final LiveData<List<Parcela>> mOrderedParcelasOCUPANTES;

    private final long TIMEOUT = 15000;

    /**
     * Constructor del repositorio. Se inicializan el DAO y las listas observables.
     *
     * @param application Contexto de la aplicación utilizado para obtener la instancia de la base de datos.
     */
    public ParcelaRepository(Application application) {
        CampingRoomDatabase db = CampingRoomDatabase.getDatabase(application);
        mParcelaDao = db.parcelaDao();
        mAllParcelas = mParcelaDao.getAllParcelas();
        mOrderedParcelasID = mParcelaDao.getOrderedParcelasID();
        mOrderedParcelasPRECIO = mParcelaDao.getOrderedParcelasPRECIO();
        mOrderedParcelasOCUPANTES = mParcelaDao.getOrderedParcelasOCUPANTES();
        //mNumeroParcelas = mParcelaDao.getNumeroParcelas();
    }

    /**
     * Obtiene todas las parcelas de la base de datos.
     *
     * @return Lista observable de todas las parcelas.
     */
    public LiveData<List<Parcela>> getAllParcelas() {
        return mAllParcelas;
    }

    /**
     * Obtiene las parcelas ordenadas por su identificador en orden ascendente.
     *
     * @return Lista observable de parcelas ordenadas por ID.
     */
    public LiveData<List<Parcela>> getOrderedParcelasID() { return mOrderedParcelasID; }

    /**
     * Obtiene las parcelas ordenadas por precio por persona en orden ascendente.
     *
     * @return Lista observable de parcelas ordenadas por precio.
     */
    public LiveData<List<Parcela>> getOrderedParcelasPRECIO() { return mOrderedParcelasPRECIO; }

    /**
     * Obtiene las parcelas ordenadas por número máximo de ocupantes en orden ascendente.
     *
     * @return Lista observable de parcelas ordenadas por número de ocupantes.
     */
    public LiveData<List<Parcela>> getOrderedParcelasOCUPANTES() { return mOrderedParcelasOCUPANTES; }

    /**
     * Obtiene el número total de parcelas en la base de datos.
     *
     * @return Número total de parcelas o -1 si ocurre un error durante la operación.
     */
    public int getNumeroParcelas() {
        Future<Integer> future = CampingRoomDatabase.databaseWriteExecutor.submit(
                () -> mParcelaDao.getNumeroParcelas());
        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.e("ParcelaRepository", ex.getClass().getSimpleName() + ": " + ex.getMessage());
            return -1;
        }
    }

    /**
     * Inserta una nueva parcela en la base de datos.
     *
     * @param parcela Parcela a insertar. Debe contener todos sus atributos correctamente inicializados.
     * @return ID de la parcela insertada o -1 si ocurre un error.
     */
    public long insert(Parcela parcela) {
        Future<Long> future = CampingRoomDatabase.databaseWriteExecutor.submit(
                () -> mParcelaDao.insert(parcela));
        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("ParcelaRepository", ex.getClass().getSimpleName() + ex.getMessage());
            return -1;
        }
    }

    /**
     * Actualiza una parcela existente en la base de datos.
     *
     * @param parcela Parcela con los datos actualizados. Debe contener un identificador válido.
     * @return Número de filas actualizadas o -1 si ocurre un error.
     */
    public int update(Parcela parcela) {
        Future<Integer> future = CampingRoomDatabase.databaseWriteExecutor.submit(
                () -> mParcelaDao.update(parcela));
        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("ParcelaRepository", ex.getClass().getSimpleName() + ex.getMessage());
            return -1;
        }
    }


    /** Elimina una parcela en la base de datos.
    /**
     * Elimina una parcela de la base de datos.
     *
     * @param parcela Parcela que se desea eliminar. Su identificador debe coincidir con una existente en la base de datos.
     * @return Número de filas eliminadas o -1 si ocurre un error.
     */
    public int delete(Parcela parcela) {
        Future<Integer> future = CampingRoomDatabase.databaseWriteExecutor.submit(
                () -> mParcelaDao.delete(parcela));
        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("ParcelaRepository", ex.getClass().getSimpleName() + ex.getMessage());
            return -1;
        }
    }
}
