package es.unizar.eina.notepad.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Update;
import androidx.room.Delete;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import java.util.List;

/**
 * Interfaz AsociacionDao para acceder y manipular datos en la tabla "asociacion".
 * Define las operaciones de base de datos.
 */
@Dao
public interface AsociacionDao {

    /**
     * Inserta una nueva asociación en la tabla "asociacion".
     * Si hay un conflicto (por ejemplo, un duplicado en la clave primaria), ignora la inserción.
     *
     * @param asociacion La entidad Asociacion a insertar.
     * @return El ID de la fila insertada. Si se ignora, devolverá -1.
     */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    long insert(Asociacion asociacion);

    /**
     * Actualiza una asociación existente en la tabla "asociacion".
     *
     * @param asociacion La entidad Asociacion con los datos actualizados.
     * @return El número de filas afectadas por la actualización.
     */
    @Update
    int update(Asociacion asociacion);

    /**
     * Elimina una asociación específica de la tabla "asociacion".
     *
     * @param asociacion La entidad Asociacion a eliminar.
     * @return El número de filas eliminadas.
     */
    @Delete
    int delete(Asociacion asociacion);

    /**
     * Elimina todas las asociaciones de la tabla "asociacion".
     */
    @Query("DELETE FROM asociacion")
    void deleteAll();

    /**
     * Recupera una lista de todas las asociaciones de la tabla "asociacion".
     * Los datos se envuelven en un LiveData para que se puedan observar cambios en tiempo real.
     *
     * @return Una lista observable de todas las entidades Asociacion.
     */
    @Query("SELECT * FROM asociacion")
    LiveData<List<Asociacion>> getAllAsociaciones();

    /**
     * Elimina todas las asociaciones relacionadas con un ID de reserva específico.
     *
     * @param reservaId El ID de la reserva cuyas asociaciones deben eliminarse.
     */
    @Query("DELETE FROM asociacion WHERE reservaId = :reservaId")
    void deleteAllAsociacionesByReserva(int reservaId);
}
