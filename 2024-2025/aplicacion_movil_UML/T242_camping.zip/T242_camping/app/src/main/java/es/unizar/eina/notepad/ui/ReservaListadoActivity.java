package es.unizar.eina.notepad.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import es.unizar.eina.notepad.R;
import es.unizar.eina.notepad.database.Reserva;

/**
 * Pantalla que muestra un listado de reservas.
 * Muestra detalles como identificador, nombre del cliente, número móvil y fecha de entrada.
 * Permite ordenar el listado por diferentes criterios: nombre del cliente, número móvil y fecha de entrada.
 */
public class ReservaListadoActivity extends AppCompatActivity {

    private ReservaViewModel mReservaViewModel;
    private RecyclerView mRecyclerView;
    private ReservaListadoAdapter mAdapter;

    private Spinner mSpinnerOrdenar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservas_list);

        mRecyclerView = findViewById(R.id.recyclerview_reservas);
        mAdapter = new ReservaListadoAdapter();
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Configurar el Spinner de ordenación
        mSpinnerOrdenar = findViewById(R.id.spinner_ordenar);
        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(
                this, R.array.criterios_ordenacion_reservas, android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mSpinnerOrdenar.setAdapter(spinnerAdapter);

        mReservaViewModel = new ViewModelProvider(this).get(ReservaViewModel.class);

        // Configurar el comportamiento del Spinner al seleccionar un criterio de ordenación
        mSpinnerOrdenar.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0: // Ordenar por Nombre del cliente
                        observarListaReservas(mReservaViewModel.getOrderedReservasNOM());
                        break;
                    case 1: // Ordenar por Número Móvil del cliente
                        observarListaReservas(mReservaViewModel.getOrderedReservasNUMMOVIL());
                        break;
                    case 2: // Ordenar por Fecha de entrada
                        observarListaReservas(mReservaViewModel.getOrderedReservasFENT());
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // No hacer nada si no hay selección
            }
        });
        // Cargar la lista inicial de reservas (sin orden específico)
        observarListaReservas(mReservaViewModel.getAllReservas());
    }

    /**
     * Observa una lista de reservas y actualiza el adaptador del RecyclerView.
     * @param reservasLiveData LiveData que contiene la lista de reservas.
     */
    private void observarListaReservas(LiveData<List<Reserva>> reservasLiveData) {
        reservasLiveData.observe(this, reservas -> {
            if (reservas != null) {
                mAdapter.setReservas(reservas);
            }
        });
    }
}


