package es.unizar.eina.notepad.ui;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import es.unizar.eina.notepad.R;
import es.unizar.eina.notepad.database.Parcela;

/**
 * Pantalla para crear una parcela.
 * Permite al usuario introducir datos sobre la parcela, como:
 * - Nombre de la parcela
 * - Tamaño
 * - Número máximo de ocupantes
 * - Precio por persona
 * - Disponibilidad de agua y luz
 */
public class ParcelaCreateActivity extends AppCompatActivity {

    private EditText mTextId, mEditTamano, mEditNumMaxOcupantes, mEditPrecioPorPersona;
    private CheckBox mEditDisponibilidadAgua, mEditDisponibilidadLuz;
    private Button mButtonSave;

    private ParcelaViewModel mParcelaViewModel;

    /**
     * Método llamado al crear la actividad.
     * Inicializa la interfaz y configura los eventos.
     * @param savedInstanceState Estado previamente guardado de la actividad, si existe.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parcela_create);

        // Inicializamos los campos de texto
        mTextId = findViewById(R.id.create_id);
        mEditTamano = findViewById(R.id.create_tamano);
        mEditDisponibilidadAgua = findViewById(R.id.create_check_disponibilidad_agua);
        mEditDisponibilidadLuz = findViewById(R.id.create_check_disponibilidad_luz);
        mEditNumMaxOcupantes = findViewById(R.id.create_num_max_ocupantes);
        mEditPrecioPorPersona = findViewById(R.id.create_precio);
        mButtonSave = findViewById(R.id.button_save);

        mParcelaViewModel = new ViewModelProvider(this).get(ParcelaViewModel.class);

        // Configuramos el evento del botón para guardar los cambios
        mButtonSave.setOnClickListener(v -> saveParcela());
    }

    /**
     * Método que guarda una nueva parcela en la base de datos.
     * Valida los datos de entrada, los procesa y los almacena.
     */
    private void saveParcela() {
        // Recuperar y validar el identificador de la parcela
        String id = mTextId.getText().toString().trim();
        if (id.isEmpty()) {
            mTextId.setError("el nombre de la parcela no puede estar vacío");
            return;
        }

        // Recuperar y validar el tamaño de la parcela
        String preTamano = mEditTamano.getText().toString().trim();
        if (preTamano.isEmpty()) {
            mEditTamano.setError("el tamaño de la parcela es obligatorio");
            return;
        }
        double tamano = Double.parseDouble(preTamano);

        // Recuperar el estado de los CheckBoxes de disponibilidad
        boolean disponibilidadAgua = mEditDisponibilidadAgua.isChecked();
        boolean disponibilidadLuz = mEditDisponibilidadLuz.isChecked();

        // Recuperar y validar el número máximo de ocupantes
        String preNumMaxOcupantes = mEditNumMaxOcupantes.getText().toString().trim();
        if (preNumMaxOcupantes.isEmpty()) {
            mEditNumMaxOcupantes.setError("el número máximo de ocupantes es obligatorio");
            return;
        }
        int numMaxOcupantes = Integer.parseInt(preNumMaxOcupantes);

        // Recuperar y validar el precio por persona
        String prePrecioPorPersona = mEditPrecioPorPersona.getText().toString().trim();
        if (prePrecioPorPersona.isEmpty()) {
            mEditPrecioPorPersona.setError("el precio por persona es obligatorio");
        }
        double precioPorPersona = Double.parseDouble(prePrecioPorPersona);

        // Crear el objeto Parcela con los datos introducidos
        Parcela parcela = new Parcela(id, tamano, disponibilidadAgua, disponibilidadLuz, numMaxOcupantes, precioPorPersona);

        // Insertar la nueva parcela en la base de datos
        mParcelaViewModel.insert(parcela);

        // Finalizar la actividad y regresar a la pantalla anterior
        finish();
    }
}

