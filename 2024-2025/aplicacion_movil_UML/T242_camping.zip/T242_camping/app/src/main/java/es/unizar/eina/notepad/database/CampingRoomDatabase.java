package es.unizar.eina.notepad.database;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Base de datos del camping que almacena: parcelas, reservas y las parcelas asociadas a cada reserva.
 * Consta de 3 entidades: Parcela, Reserva y Asociacion
 */
@Database(entities = {Parcela.class, Reserva.class, Asociacion.class}, version = 6, exportSchema = false)
public abstract class CampingRoomDatabase extends RoomDatabase {

    // Métodos abstractos para obtener los DAOs correspondientes a cada entidad    public abstract ParcelaDao parcelaDao();
    public abstract ParcelaDao parcelaDao();
    public abstract ReservaDao reservaDao();
    public abstract AsociacionDao asociacionDao();

    private static volatile CampingRoomDatabase INSTANCE;
    private static final int NUMBER_OF_THREADS = 4;
    static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    /**
     * Método para obtener la instancia única de la base de datos.
     *
     * @param context Contexto de la aplicación para inicializar la base de datos.
     * @return Instancia única de CampingRoomDatabase.
     */
    static CampingRoomDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (CampingRoomDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    CampingRoomDatabase.class, "camping_database")
                            .fallbackToDestructiveMigration()
                            .addCallback(sRoomDatabaseCallback)
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    /**
     * Callback para inicializar o realizar tareas adicionales al abrir la base de datos.
     * Se puede usar para insertar datos de ejemplo o realizar configuraciones iniciales.
     */
    private static Callback sRoomDatabaseCallback = new Callback() {
        @Override
        public void onOpen(@NonNull SupportSQLiteDatabase db) {
            super.onOpen(db);

            databaseWriteExecutor.execute(() -> {
                ParcelaDao dao = INSTANCE.parcelaDao();
//                dao.deleteAll();

//                Parcela parcela = new Parcela("MONTEJURRA", 20.5, true, true, 6, 50);
//                dao.insert(parcela);
//                parcela = new Parcela("VALLE DEL LOBO", 60.3, false, true, 10, 30);
//                dao.insert(parcela);
//                parcela = new Parcela("MONTE LUCHO", 60.3, false, true, 10, 30);
//                dao.insert(parcela);
//                parcela = new Parcela("ALTO VERA", 60.3, false, true, 10, 30);
//                dao.insert(parcela);
//                parcela = new Parcela("VALLE DEL SUR", 60.3, false, true, 10, 30);
//                dao.insert(parcela);
//                parcela = new Parcela("MONTE DEL CANAL", 60.3, false, true, 10, 30);
//                dao.insert(parcela);
//                parcela = new Parcela("VALLE CIRIO", 60.3, false, true, 10, 30);
//                dao.insert(parcela);
//                parcela = new Parcela("EL CAÑÓN", 60.3, false, true, 10, 30);
//                dao.insert(parcela);
//                parcela = new Parcela("EL LAGO SIGILIO", 60.3, false, true, 10, 30);
//                dao.insert(parcela);
//                parcela = new Parcela("MONTE PERDIDO", 60.3, false, true, 10, 30);
//                dao.insert(parcela);
//                parcela = new Parcela("LOS PIRINEOS", 60.3, false, true, 10, 30);
//                dao.insert(parcela);
//                parcela = new Parcela("VALLE DE TENA", 60.3, false, true, 10, 30);
//                dao.insert(parcela);
//                parcela = new Parcela("CERRO NEGRO", 45.7, true, false, 8, 40);
//                dao.insert(parcela);
//                parcela = new Parcela("SIERRA MORENA", 70.1, true, true, 12, 25);
//                dao.insert(parcela);
//                parcela = new Parcela("COLINAS VERDES", 50.0, false, false, 7, 35);
//                dao.insert(parcela);
//                parcela = new Parcela("LAGO ESCONDIDO", 25.4, true, false, 5, 45);
//                dao.insert(parcela);
//                parcela = new Parcela("BOSQUE PROFUNDO", 33.6, false, true, 9, 20);
//                dao.insert(parcela);

                ReservaDao dao2 = INSTANCE.reservaDao();
//                dao2.deleteAll();

                AsociacionDao dao3 = INSTANCE.asociacionDao();
                //dao3.deleteAll();
            });
        }
    };
}
