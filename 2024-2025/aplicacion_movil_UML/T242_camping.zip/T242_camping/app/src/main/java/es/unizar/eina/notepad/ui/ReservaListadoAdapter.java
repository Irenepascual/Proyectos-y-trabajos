package es.unizar.eina.notepad.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import es.unizar.eina.notepad.R;
import es.unizar.eina.notepad.database.Reserva;


/**
 * Adaptador para mostrar un listado de reservas en un RecyclerView.
 * Cada elemento del listado incluye:
 * - Identificador de la reserva
 * - Nombre del cliente
 * - Número móvil del cliente
 * - Fecha de entrada
 */public class ReservaListadoAdapter extends RecyclerView.Adapter<ReservaListadoAdapter.ReservaViewHolder> {

    private List<Reserva> mReservas;

    /**
     * Constructor del adaptador.
     */
    public ReservaListadoAdapter() {
    }

    /**
     * Establece la lista de reservas y notifica al adaptador que los datos han cambiado.
     * @param reservas Lista de objetos Reserva.
     */
    public void setReservas(List<Reserva> reservas) {
        mReservas = reservas;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ReservaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_reserva_listado, parent, false);
        return new ReservaViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ReservaViewHolder holder, int position) {
        if (mReservas != null) {
            Reserva current = mReservas.get(position);
            holder.bind(current);
        }
    }

    @Override
    public int getItemCount() {
        return (mReservas != null) ? mReservas.size() : 0;
    }

    /**
     * Clase interna que representa cada elemento visual en el RecyclerView.
     */
    static class ReservaViewHolder extends RecyclerView.ViewHolder {
        private final TextView idReserva;
        private final TextView nomClienteReserva;
        private final TextView numMovilReserva;

        private final TextView fEntReserva;

        /**
         * Constructor que inicializa los componentes visuales del elemento.
         * @param itemView Vista del elemento.
         */
        public ReservaViewHolder(@NonNull View itemView) {
            super(itemView);
            idReserva = itemView.findViewById(R.id.idReserva);
            nomClienteReserva = itemView.findViewById(R.id.nomClienteReserva);
            numMovilReserva = itemView.findViewById(R.id.numMovilReserva);
            fEntReserva = itemView.findViewById(R.id.fEntReserva);
        }

        /**
         * Vincula los datos de una reserva a los componentes visuales del ViewHolder.
         * @param reserva Objeto Reserva cuyos datos se mostrarán.
         */
        public void bind(final Reserva reserva) {
            idReserva.setText(String.valueOf(reserva.getId()));
            nomClienteReserva.setText(String.valueOf(reserva.getNomCliente()));
            numMovilReserva.setText(String.valueOf(reserva.getNumMovil()));
            fEntReserva.setText(String.valueOf(reserva.getFEnt()));
        }
    }
}