package es.unizar.eina.notepad.ui;

import android.app.Application;
import android.util.Log;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import java.util.List;

import es.unizar.eina.notepad.database.Reserva;
import es.unizar.eina.notepad.database.ReservaRepository;


public class ReservaViewModel extends AndroidViewModel {

    int MAX_RESERVAS = 10000;

    private final ReservaRepository mRepository;
    private final LiveData<List<Reserva>> mAllReservas;
    private final MutableLiveData<Long> mInsertedReservaId = new MutableLiveData<>(); // LiveData para el ID de la reserva insertada

    /**
     * Constructor que inicializa el ViewModel y carga el repositorio y las reservas.
     * @param application Contexto de la aplicación.
     */
    public ReservaViewModel(Application application) {
        super(application);
        mRepository = new ReservaRepository(application);
        mAllReservas = mRepository.getAllReservas();
    }

    /**
     * Obtiene todas las reservas como un LiveData.
     * @return LiveData con la lista de todas las reservas.
     */
    public LiveData<List<Reserva>> getAllReservas() {
        return mAllReservas;
    }

    /**
     * Obtiene las reservas ordenadas por nombre del cliente.
     * @return LiveData con la lista de reservas ordenada por nombre.
     */
    public LiveData<List<Reserva>> getOrderedReservasNOM() { return mRepository.getOrderedReservasNOM(); }

    /**
     * Obtiene las reservas ordenadas por número móvil del cliente.
     * @return LiveData con la lista de reservas ordenada por número móvil.
     */
    public LiveData<List<Reserva>> getOrderedReservasNUMMOVIL() { return mRepository.getOrderedReservasNUMMOVIL(); }

    /**
     * Obtiene las reservas ordenadas por fecha de entrada.
     * @return LiveData con la lista de reservas ordenada por fecha de entrada.
     */
    public LiveData<List<Reserva>> getOrderedReservasFENT() { return mRepository.getOrderedReservasFENT(); }

    /**
     * Obtiene una reserva específica por su ID.
     * @param id Identificador de la reserva.
     * @return LiveData con la reserva correspondiente.
     */
    public LiveData<Reserva> getReservaById(int id) { return mRepository.getReservaById(id); }

    /**
     * Obtiene el número total de reservas.
     * @return Número de reservas en la base de datos.
     */
     
    public int getNumeroReservas() { return mRepository.getNumeroReservas(); }

    /**
     * Obtiene el número máximo permitido de reservas.
     * @return Número máximo de reservas.
     */
    public int getNumeroMaxReservas() { return MAX_RESERVAS; }

    /**
     * Obtiene el ID de la última reserva insertada.
     * @return LiveData con el ID de la reserva insertada.
     */
    public LiveData<Long> getInsertedReservaId() {
        return mInsertedReservaId;  
    }

    /**
     * Elimina una reserva específica.
     * @param reserva Reserva a eliminar.
     */
    public void delete(Reserva reserva) {
        if (reserva.getId() < 0) {
            Log.d("ReservaViewModel", "id no válido");
            return;
        }
        mRepository.delete(reserva);
    }

    /**
     * Actualiza una reserva existente con validaciones para asegurar la consistencia de los datos.
     * @param reserva Reserva a actualizar.
     */
    public void update(Reserva reserva) {
        if (reserva.getNomCliente() == null || reserva.getNomCliente().isEmpty()) {
            Log.d("ReservaViewModel", "ERROR: nomCliente no válido");
            return;
        }
        if (reserva.getNumMovil() < 100000000 || reserva.getNumMovil() > 999999999) {
            Log.d("ReservaViewModel", "ERROR: numMovil no válido");
            return;
        }
        if (reserva.getFEnt().length() != 10 || reserva.getFEnt().charAt(2) != '/' ||
                reserva.getFEnt().charAt(5) != '/') {
            Log.d("ReservaViewModel", "ERROR: fEnt no válido");
            return;
        }
        char dia1Ent = reserva.getFEnt().charAt(0);
        char dia2Ent = reserva.getFEnt().charAt(1);
        char mes1Ent = reserva.getFEnt().charAt(3);
        char mes2Ent = reserva.getFEnt().charAt(4);
        char ano1Ent = reserva.getFEnt().charAt(6);
        char ano2Ent = reserva.getFEnt().charAt(7);
        char ano3Ent = reserva.getFEnt().charAt(8);
        char ano4Ent = reserva.getFEnt().charAt(9);
        if (dia1Ent < '0' || dia1Ent > '9' || dia2Ent < '0' || dia2Ent > '9' ||
                mes1Ent < '0' || mes1Ent > '9' || mes2Ent < '0' || mes2Ent > '9' ||
                ano1Ent < '0' || ano1Ent > '9' || ano2Ent < '0' || ano2Ent > '9' ||
                ano3Ent < '0' || ano3Ent > '9' || ano4Ent < '0' || ano4Ent > '9') {
            Log.d("ReservaViewModel", "ERROR: fEnt no válido");
            return;
        }
        if (reserva.getFSal().length() != 10 || reserva.getFSal().charAt(2) != '/' ||
                reserva.getFSal().charAt(5) != '/') {
            Log.d("ReservaViewModel", "ERROR: fSal no válido");
            return;
        }
        char dia1Sal = reserva.getFSal().charAt(0);
        char dia2Sal = reserva.getFSal().charAt(1);
        char mes1Sal = reserva.getFSal().charAt(3);
        char mes2Sal = reserva.getFSal().charAt(4);
        char ano1Sal = reserva.getFSal().charAt(6);
        char ano2Sal = reserva.getFSal().charAt(7);
        char ano3Sal = reserva.getFSal().charAt(8);
        char ano4Sal = reserva.getFSal().charAt(9);
        if (dia1Sal < '0' || dia1Sal > '9' || dia2Sal < '0' || dia2Sal > '9' ||
                mes1Sal < '0' || mes1Sal > '9' || mes2Sal < '0' || mes2Sal > '9' ||
                ano1Sal < '0' || ano1Sal > '9' || ano2Sal < '0' || ano2Sal > '9' ||
                ano3Sal < '0' || ano3Sal > '9' || ano4Sal < '0' || ano4Sal > '9') {
            Log.d("ReservaViewModel", "ERROR: fSal no válido");
            return;
        }
        if (reserva.getNumParcelas() <= 0) {
            Log.d("ReservaViewModel", "ERROR: numParcelas no válido");
            return;
        }
        mRepository.update(reserva);
    }

    /**
     * Inserta una nueva reserva con validaciones.
     * @param reserva Reserva a insertar.
     */
    public void insert(Reserva reserva) {
        if (mRepository.getNumeroReservas() == MAX_RESERVAS) {
            Log.d("ReservaViewModel", "ERROR: alcanzado el máximo de reservas (" + MAX_RESERVAS + ")");
            return;
        }

        if (reserva.getId() < 0) {
            Log.d("ReservaViewModel", "ERROR: id no válido");
            return;
        }
        if (reserva.getNomCliente() == null || reserva.getNomCliente().isEmpty()) {
            Log.d("ReservaViewModel", "ERROR: nomCliente no válido");
            return;
        }
        if (reserva.getNumMovil() < 100000000 || reserva.getNumMovil() > 999999999) {
            Log.d("ReservaViewModel", "ERROR: numMovil no válido");
            return;
        }
        if (reserva.getFEnt().length() != 10 || reserva.getFEnt().charAt(2) != '/' ||
                reserva.getFEnt().charAt(5) != '/') {
            Log.d("ReservaViewModel", "ERROR: fEnt no válido");
            return;
        }
        char dia1Ent = reserva.getFEnt().charAt(0);
        char dia2Ent = reserva.getFEnt().charAt(1);
        char mes1Ent = reserva.getFEnt().charAt(3);
        char mes2Ent = reserva.getFEnt().charAt(4);
        char ano1Ent = reserva.getFEnt().charAt(6);
        char ano2Ent = reserva.getFEnt().charAt(7);
        char ano3Ent = reserva.getFEnt().charAt(8);
        char ano4Ent = reserva.getFEnt().charAt(9);
        if (dia1Ent < '0' || dia1Ent > '9' || dia2Ent < '0' || dia2Ent > '9' ||
                mes1Ent < '0' || mes1Ent > '9' || mes2Ent < '0' || mes2Ent > '9' ||
                ano1Ent < '0' || ano1Ent > '9' || ano2Ent < '0' || ano2Ent > '9' ||
                ano3Ent < '0' || ano3Ent > '9' || ano4Ent < '0' || ano4Ent > '9') {
            Log.d("ReservaViewModel", "ERROR: fEnt no válido");
            return;
        }
        if (reserva.getFSal().length() != 10 || reserva.getFSal().charAt(2) != '/' ||
                reserva.getFSal().charAt(5) != '/') {
            Log.d("ReservaViewModel", "ERROR: fSal no válido");
            return;
        }
        char dia1Sal = reserva.getFSal().charAt(0);
        char dia2Sal = reserva.getFSal().charAt(1);
        char mes1Sal = reserva.getFSal().charAt(3);
        char mes2Sal = reserva.getFSal().charAt(4);
        char ano1Sal = reserva.getFSal().charAt(6);
        char ano2Sal = reserva.getFSal().charAt(7);
        char ano3Sal = reserva.getFSal().charAt(8);
        char ano4Sal = reserva.getFSal().charAt(9);
        if (dia1Sal < '0' || dia1Sal > '9' || dia2Sal < '0' || dia2Sal > '9' ||
                mes1Sal < '0' || mes1Sal > '9' || mes2Sal < '0' || mes2Sal > '9' ||
                ano1Sal < '0' || ano1Sal > '9' || ano2Sal < '0' || ano2Sal > '9' ||
                ano3Sal < '0' || ano3Sal > '9' || ano4Sal < '0' || ano4Sal > '9') {
            Log.d("ReservaViewModel", "ERROR: fSal no válido");
            return;
        }
        if (reserva.getNumParcelas() <= 0) {
            Log.d("ReservaViewModel", "ERROR: numParcelas no válido");
            return;
        }

        // Insertamos la reserva y obtenemos el ID generado
        long id = mRepository.insert(reserva);
        if (id > 0) {
            // Si la inserción es exitosa, actualizamos el LiveData con el ID
            mInsertedReservaId.setValue(id);
        } 
    }
}