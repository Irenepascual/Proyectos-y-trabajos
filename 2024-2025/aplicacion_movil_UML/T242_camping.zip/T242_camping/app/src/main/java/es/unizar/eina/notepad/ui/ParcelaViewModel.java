package es.unizar.eina.notepad.ui;

import android.app.Application;
import android.util.Log;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import java.util.List;
import es.unizar.eina.notepad.database.Parcela;
import es.unizar.eina.notepad.database.ParcelaRepository;

/**
 * Clase ParcelaViewModel que actúa como un puente entre la interfaz de usuario (UI) y la fuente de datos (base de datos).
 * Proporciona acceso a los datos de las parcelas y las operaciones relacionadas con ellas.
 */
public class ParcelaViewModel extends AndroidViewModel {

    private int MAX_PARCELAS = 100;
    private final ParcelaRepository mRepository;
    private final LiveData<List<Parcela>> mAllParcelas;


    /**
     * Constructor del ViewModel que inicializa el repositorio y obtiene la lista de parcelas.
     * @param application Contexto de la aplicación.
     */
    public ParcelaViewModel(Application application) {
        super(application);
        mRepository = new ParcelaRepository(application);
        mAllParcelas = mRepository.getAllParcelas();
    }

    /**
     * Devuelve una lista observable con todas las parcelas.
     * @return Lista observable de todas las parcelas.
     */
    public LiveData<List<Parcela>> getAllParcelas() {
        return mAllParcelas;
    }

    /**
     * Devuelve una lista observable con las parcelas ordenadas por ID.
     * @return Lista observable de parcelas ordenadas por ID.
     */
    public LiveData<List<Parcela>> getOrderedParcelasID() { return mRepository.getOrderedParcelasID(); }

    /**
     * Devuelve una lista observable con las parcelas ordenadas por precio por persona.
     * @return Lista observable de parcelas ordenadas por precio.
     */
    public LiveData<List<Parcela>> getOrderedParcelasPRECIO() { return mRepository.getOrderedParcelasPRECIO(); }

    /**
     * Devuelve una lista observable con las parcelas ordenadas por número máximo de ocupantes.
     * @return Lista observable de parcelas ordenadas por número de ocupantes.
     */
    public LiveData<List<Parcela>> getOrderedParcelasOCUPANTES() { return mRepository.getOrderedParcelasOCUPANTES(); }

    /**
     * Devuelve el número total de parcelas existentes en el sistema.
     * @return Número total de parcelas.
     */
    public int getNumeroParcelas() { return mRepository.getNumeroParcelas(); }

    /**
     * Devuelve el número máximo permitido de parcelas.
     * @return Número máximo de parcelas permitidas.
     */
    public int getNumeroMaxParcelas() { return MAX_PARCELAS; }

    /**
     * Elimina una parcela del sistema, previa validación.
     * @param parcela Objeto Parcela que se desea eliminar.
     */
    public void delete(Parcela parcela) {
        if (parcela.getId() == null || parcela.getId().isEmpty()) {
            Log.d("ParcelaViewModel", "id no válido");
            return;
        }
        mRepository.delete(parcela);
    }

    /**
     * Actualiza una parcela existente en el sistema, previa validación.
     * @param parcela Objeto Parcela que se desea actualizar.
     */
    public void update(Parcela parcela) {
        if (parcela.getTamano() <= 0.0) {
            Log.d("ParcelaViewModel", "ERROR: tamano no válido");
            return;
        }
        if (parcela.getNumMaxOcupantes() <= 0) {
            Log.d("ParcelaViewModel", "ERROR: numMaxOcupantes no válido");
            return;
        }
        if (parcela.getPrecioPorPersona() <= 0.0) {
            Log.d("ParcelaViewModel", "ERROR: precioPorPersona no válido");
            return;
        }
        mRepository.update(parcela);
    }

    /**
     * Inserta una nueva parcela en el sistema, previa validación.
     * @param parcela Objeto Parcela que se desea insertar.
     */
    public void insert(Parcela parcela) {
        if (mRepository.getNumeroParcelas() == MAX_PARCELAS) {
            Log.d("ParcelaViewModel", "ERROR: alcanzado el máximo de parcelas (" + MAX_PARCELAS + ")");
            return;
        }

        if (parcela.getId() == null || parcela.getId().isEmpty()) {
            Log.d("ParcelaViewModel", "ERROR: id no válido");
            return;
        }
        if (parcela.getTamano() <= 0.0) {
            Log.d("ParcelaViewModel", "ERROR: tamano no válido");
            return;
        }
        if (parcela.getNumMaxOcupantes() <= 0) {
            Log.d("ParcelaViewModel", "ERROR: numMaxOcupantes no válido");
            return;
        }
        if (parcela.getPrecioPorPersona() <= 0.0) {
            Log.d("ParcelaViewModel", "ERROR: precioPorPersona no válido");
            return;
        }

        mRepository.insert(parcela);
    }
}


