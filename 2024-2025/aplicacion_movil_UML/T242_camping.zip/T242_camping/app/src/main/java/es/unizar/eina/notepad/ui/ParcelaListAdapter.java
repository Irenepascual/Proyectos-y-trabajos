package es.unizar.eina.notepad.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import es.unizar.eina.notepad.R;
import es.unizar.eina.notepad.database.Parcela;

/**
 * Adaptador para mostrar un listado de parcelas en un RecyclerView.
 * Permite la interacción con cada parcela a través de botones para editar y eliminar.
 */
public class ParcelaListAdapter extends RecyclerView.Adapter<ParcelaListAdapter.ParcelaViewHolder> {

    private List<Parcela> mParcelas;
    private final OnEditClickListener mEditListener;
    private final OnDeleteClickListener mDeleteListener;

    /**
     * Interfaz para manejar los eventos de clic en el botón de editar.
     */
    public interface OnEditClickListener {
        void onEditClick(Parcela parcela);
    }

    /**
     * Interfaz para manejar los eventos de clic en el botón de eliminar.
     */
    public interface OnDeleteClickListener {
        void onDeleteClick(Parcela parcela);
    }

    /**
     * Constructor del adaptador.
     * @param editListener Listener para manejar eventos de edición.
     * @param deleteListener Listener para manejar eventos de eliminación.
     */
    public ParcelaListAdapter(OnEditClickListener editListener, OnDeleteClickListener deleteListener) {
        mEditListener = editListener;
        mDeleteListener = deleteListener;
    }

    /**
     * Establece la lista de parcelas a mostrar en el RecyclerView.
     * @param parcelas Lista de parcelas.
     */
    public void setParcelas(List<Parcela> parcelas) {
        mParcelas = parcelas;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ParcelaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_parcela, parent, false);
        return new ParcelaViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ParcelaViewHolder holder, int position) {
        if (mParcelas != null) {
            Parcela current = mParcelas.get(position);
            holder.bind(current, mEditListener, mDeleteListener);
        }
    }

    @Override
    public int getItemCount() {
        return (mParcelas != null) ? mParcelas.size() : 0;
    }

    /**
     * ViewHolder que contiene las vistas para cada elemento de la lista de parcelas.
     */
    static class ParcelaViewHolder extends RecyclerView.ViewHolder {
        private final TextView nombreParcela;
        private final ImageButton buttonEdit;
        private final ImageButton buttonDelete;


        /**
         * Constructor del ViewHolder.
         * @param itemView Vista del elemento de parcela.
         */
        public ParcelaViewHolder(@NonNull View itemView) {
            super(itemView);
            nombreParcela = itemView.findViewById(R.id.textViewParcela);
            buttonEdit = itemView.findViewById(R.id.buttonEdit);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }

        /**
         * Vincula los datos de una parcela a las vistas del ViewHolder.
         * @param parcela Parcela a mostrar.
         * @param editListener Listener para manejar eventos de edición.
         * @param deleteListener Listener para manejar eventos de eliminación.
         */
        public void bind(final Parcela parcela, final OnEditClickListener editListener, final OnDeleteClickListener deleteListener) {
            nombreParcela.setText(parcela.getId());

            // Configura el botón de editar para llamar al listener correspondiente
            buttonEdit.setOnClickListener(v -> editListener.onEditClick(parcela));

            // Configura el botón de eliminar para llamar al listener correspondiente
            buttonDelete.setOnClickListener(v -> deleteListener.onDeleteClick(parcela));
        }
    }
}