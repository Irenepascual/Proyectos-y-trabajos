package es.unizar.eina.notepad.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

/** 
 * Interfaz que define un Data Access Object (DAO) para la entidad Parcela.
 * Proporciona métodos para interactuar con la tabla de parcelas en la base de datos.
 */
 @Dao
public interface ParcelaDao {

    /**
     * Inserta una nueva parcela en la base de datos.
     * Si ya existe una parcela con el mismo identificador, se ignora la inserción.
     * 
     * @param parcela la parcela que se desea insertar
     * @return el ID de la fila insertada, o -1 si la inserción fue ignorada
     */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    long insert(Parcela parcela);

    /**
     * Actualiza los datos de una parcela existente en la base de datos.
     * 
     * @param parcela la parcela con los datos actualizados
     * @return el número de filas afectadas por la actualización
     */
    @Update
    int update(Parcela parcela);

    /**
     * Elimina una parcela específica de la base de datos.
     * 
     * @param parcela la parcela que se desea eliminar
     * @return el número de filas afectadas por la eliminación
     */
    @Delete
    int delete(Parcela parcela);

    /**
     * Elimina todas las parcelas de la base de datos.
     */
    @Query("DELETE FROM parcela")
    void deleteAll();

    /**
     * Obtiene una lista de todas las parcelas en la base de datos.
     * 
     * @return una lista observable que contiene todas las parcelas
     */
    @Query("SELECT * FROM parcela")
    LiveData<List<Parcela>> getAllParcelas();

    /**
     * Obtiene una lista de todas las parcelas, ordenadas por su identificador en orden ascendente.
     * 
     * @return una lista observable de parcelas ordenadas por ID
     */
    @Query("SELECT * FROM parcela ORDER BY id ASC")
    LiveData<List<Parcela>> getOrderedParcelasID();

    /**
     * Obtiene una lista de todas las parcelas, ordenadas por su precio por persona en orden ascendente.
     * 
     * @return una lista observable de parcelas ordenadas por precio
     */
    @Query("SELECT * FROM parcela ORDER BY precioPorPersona ASC")
    LiveData<List<Parcela>> getOrderedParcelasPRECIO();

    /**
     * Obtiene una lista de todas las parcelas, ordenadas por el número máximo de ocupantes en orden ascendente.
     * 
     * @return una lista observable de parcelas ordenadas por número de ocupantes
     */
    @Query("SELECT * FROM parcela ORDER BY numMaxOcupantes ASC")
    LiveData<List<Parcela>> getOrderedParcelasOCUPANTES();

    /**
     * Obtiene el número total de parcelas registradas en la base de datos.
     * 
     * @return el número de parcelas
     */
    @Query("SELECT COUNT(*) FROM parcela")
    int getNumeroParcelas();
}

