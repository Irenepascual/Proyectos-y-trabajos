package es.unizar.eina.notepad.database;


import android.app.Application;
import android.util.Log;
import androidx.lifecycle.LiveData;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Repositorio para la gestión de asociaciones.
 * Este repositorio actúa como una capa intermedia entre la base de datos (DAO) y el ViewModel.
 * Proporciona métodos para interactuar con los datos de forma asincrónica.
 */
public class AsociacionRepository {
    // DAO de Asociacion para interactuar con la base de datos
    private final AsociacionDao mAsociacionDao;

    // Lista observable con todas las asociaciones
    private final LiveData<List<Asociacion>> mAllAsociaciones;

    // Tiempo límite para operaciones asincrónicas
    private final long TIMEOUT = 15000;

    /**
     * Constructor del repositorio.
     * Inicializa el DAO y obtiene la base de datos.
     *
     * @param application Contexto de la aplicación, usado para obtener la instancia de la base de datos.
     */
    public AsociacionRepository(Application application) {
        CampingRoomDatabase db = CampingRoomDatabase.getDatabase(application);
        mAsociacionDao = db.asociacionDao(); // Asegúrate de obtener el DAO correcto
        mAllAsociaciones = mAsociacionDao.getAllAsociaciones();
    }

    /**
     * Obtiene una lista observable con todas las asociaciones en la base de datos.
     *
     * @return Lista observable de todas las asociaciones.
     */
    public LiveData<List<Asociacion>> getAllAsociaciones() {
        return mAllAsociaciones;
    }

    /**
     * Inserta una nueva Asociación en la base de datos.
     * Esta operación es asincrónica y usa un executor para ejecutarse en segundo plano.
     *
     * @param asociacion La entidad Asociacion a insertar.
     * @return El ID de la nueva asociación o -1 si ocurre un error.
     */
    public long insert(Asociacion asociacion) {
        // Inserta una nueva Asociación en la base de datos
        Future<Long> future = CampingRoomDatabase.databaseWriteExecutor.submit(
                () -> mAsociacionDao.insert(asociacion));
        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("AsociacionRepository", ex.getClass().getSimpleName() + ex.getMessage());
            return -1;
        }
    }

    /**
     * Actualiza una Asociación en la base de datos.
     * Esta operación también se realiza de forma asincrónica.
     *
     * @param asociacion La entidad Asociacion con los datos actualizados.
     * @return El número de filas afectadas o -1 si ocurre un error.
     */
    public int update(Asociacion asociacion) {
        // Actualiza una Asociación en la base de datos
        Future<Integer> future = CampingRoomDatabase.databaseWriteExecutor.submit(
                () -> mAsociacionDao.update(asociacion));
        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("AsociacionRepository", ex.getClass().getSimpleName() + ex.getMessage());
            return -1;
        }
    }

    /**
     * Elimina una Asociación específica de la base de datos.
     *
     * @param asociacion La entidad Asociacion a eliminar.
     * @return El número de filas eliminadas o -1 si ocurre un error.
     */
    public int delete(Asociacion asociacion) {
        // Elimina una Asociación de la base de datos
        Future<Integer> future = CampingRoomDatabase.databaseWriteExecutor.submit(
                () -> mAsociacionDao.delete(asociacion));
        try {
            return future.get(TIMEOUT, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException ex) {
            Log.d("AsociacionRepository", ex.getClass().getSimpleName() + ex.getMessage());
            return -1;
        }
    }

    /**
     * Elimina todas las asociaciones relacionadas con un ID de reserva específico.
     * Esta operación es asincrónica.
     *
     * @param reservaId El ID de la reserva cuyas asociaciones deben eliminarse.
     */
    public void deleteAllAsociacionesByReserva(int reservaId) {
        CampingRoomDatabase.databaseWriteExecutor.execute(() ->
            mAsociacionDao.deleteAllAsociacionesByReserva(reservaId));
    }
}
