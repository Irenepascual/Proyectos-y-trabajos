package es.unizar.eina.notepad.ui;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import es.unizar.eina.notepad.R;
import es.unizar.eina.notepad.database.Parcela;

/**
 * Pantalla para editar una parcela.
 * Permite al usuario modificar los datos de una parcela, incluyendo:
 * - Tamaño
 * - Número máximo de ocupantes
 * - Precio por persona
 * - Disponibilidad de agua y luz
 */
public class ParcelaEditActivity extends AppCompatActivity {

    private TextView mTextId;
    private EditText mEditTamano, mEditNumMaxOcupantes, mEditPrecioPorPersona;
    private CheckBox mEditDisponibilidadAgua, mEditDisponibilidadLuz;
    private Button mButtonSave;

    private ParcelaViewModel mParcelaViewModel;

    /**
     * Método llamado al crear la actividad.
     * Inicializa la interfaz de usuario y configura los eventos.
     * @param savedInstanceState Estado previamente guardado de la actividad, si existe.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parcela_edit);

        // Inicializamos los campos de texto
        mTextId = findViewById(R.id.text_id);
        mEditTamano = findViewById(R.id.edit_tamano);
        mEditDisponibilidadAgua = findViewById(R.id.check_disponibilidad_agua);
        mEditDisponibilidadLuz = findViewById(R.id.check_disponibilidad_luz);
        mEditNumMaxOcupantes = findViewById(R.id.edit_num_max_ocupantes);
        mEditPrecioPorPersona = findViewById(R.id.edit_precio);
        mButtonSave = findViewById(R.id.button_save);

        mParcelaViewModel = new ViewModelProvider(this).get(ParcelaViewModel.class);

        // Recuperamos los datos enviados a través del Intent y asignarlos a los campos
        if (getIntent() != null) {
            String parcelaId = getIntent().getStringExtra("parcela_id");
            double parcelaTamano = getIntent().getDoubleExtra("parcela_tamano", 0.0);
            boolean parcelaDisponibilidadAgua = getIntent().getBooleanExtra("parcela_disponibilidad_agua", false);
            boolean parcelaDisponibilidadLuz = getIntent().getBooleanExtra("parcela_disponibilidad_luz", false);
            int parcelaNumMaxOcupantes = getIntent().getIntExtra("parcela_num_max_ocupantes", 0);
            double parcelaPrecioPorPersona = getIntent().getDoubleExtra("parcela_precio_por_persona", 0.0);

            mTextId.setText(parcelaId);
            mEditTamano.setText(String.valueOf(parcelaTamano));
            mEditDisponibilidadAgua.setChecked(parcelaDisponibilidadAgua);
            mEditDisponibilidadLuz.setChecked(parcelaDisponibilidadLuz);
            mEditNumMaxOcupantes.setText(String.valueOf(parcelaNumMaxOcupantes));
            mEditPrecioPorPersona.setText(String.valueOf(parcelaPrecioPorPersona));
        }

        // Configuramos el evento del botón para guardar los cambios
        mButtonSave.setOnClickListener(v -> saveParcela());
    }

    /**
     * Método para guardar los cambios realizados en una parcela.
     * Valida los datos de entrada, los procesa y actualiza la base de datos.
     */
    private void saveParcela() {
        // Recuperamos los datos modificados y los guardamos en la base de datos
        String id = mTextId.getText().toString();

        // Validar y recuperar el tamaño de la parcela
        String preTamano = mEditTamano.getText().toString().trim();
        if (preTamano.isEmpty()) {
            mEditTamano.setError("el tamaño de la parcela es obligatorio");
            return;
        }
        double tamano = Double.parseDouble(preTamano);

        // Recuperar el estado de los CheckBoxes de disponibilidad
        boolean disponibilidadAgua = mEditDisponibilidadAgua.isChecked();
        boolean disponibilidadLuz = mEditDisponibilidadLuz.isChecked();

        // Validar y recuperar el número máximo de ocupantes
        String preNumMaxOcupantes = mEditNumMaxOcupantes.getText().toString().trim();
        if (preNumMaxOcupantes.isEmpty()) {
            mEditNumMaxOcupantes.setError("el número máximo de ocupantes es obligatorio");
            return;
        }
        int numMaxOcupantes = Integer.parseInt(preNumMaxOcupantes);

        // Validar y recuperar el precio por persona
        String prePrecioPorPersona = mEditPrecioPorPersona.getText().toString().trim();
        if (prePrecioPorPersona.isEmpty()) {
            mEditPrecioPorPersona.setError("el precio por persona es obligatorio");
            return;
        }
        double precioPorPersona = Double.parseDouble(prePrecioPorPersona);

        // Crear el objeto Parcela con los datos actualizados
        Parcela parcela = new Parcela(id, tamano, disponibilidadAgua, disponibilidadLuz, numMaxOcupantes, precioPorPersona);

        // Actualizar la parcela en la base de datos
        mParcelaViewModel.update(parcela);

        // Finalizar la actividad y regresar a la pantalla anterior
        finish();
    }
}

